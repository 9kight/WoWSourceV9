/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50534
Source Host           : localhost:3306
Source Database       : characters

Target Server Type    : MYSQL
Target Server Version : 50534
File Encoding         : 65001

Date: 2013-12-15 23:10:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for account_data
-- ----------------------------
DROP TABLE IF EXISTS `account_data`;
CREATE TABLE `account_data` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`accountId`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_data
-- ----------------------------

-- ----------------------------
-- Table structure for account_instance_times
-- ----------------------------
DROP TABLE IF EXISTS `account_instance_times`;
CREATE TABLE `account_instance_times` (
  `accountId` int(10) unsigned NOT NULL,
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0',
  `releaseTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`,`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_instance_times
-- ----------------------------

-- ----------------------------
-- Table structure for account_tutorial
-- ----------------------------
DROP TABLE IF EXISTS `account_tutorial`;
CREATE TABLE `account_tutorial` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `tut0` int(10) unsigned NOT NULL DEFAULT '0',
  `tut1` int(10) unsigned NOT NULL DEFAULT '0',
  `tut2` int(10) unsigned NOT NULL DEFAULT '0',
  `tut3` int(10) unsigned NOT NULL DEFAULT '0',
  `tut4` int(10) unsigned NOT NULL DEFAULT '0',
  `tut5` int(10) unsigned NOT NULL DEFAULT '0',
  `tut6` int(10) unsigned NOT NULL DEFAULT '0',
  `tut7` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_tutorial
-- ----------------------------

-- ----------------------------
-- Table structure for addons
-- ----------------------------
DROP TABLE IF EXISTS `addons`;
CREATE TABLE `addons` (
  `name` varchar(120) NOT NULL DEFAULT '',
  `crc` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Addons';

-- ----------------------------
-- Records of addons
-- ----------------------------
INSERT INTO `addons` VALUES ('Blizzard_AchievementUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_ArchaeologyUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_ArenaUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_AuctionUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_BarbershopUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_BattlefieldMinimap', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_BindingUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_Calendar', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_ClientSavedVariables', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_CombatLog', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_CombatText', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_CompactRaidFrames', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_CUFProfiles', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_DebugTools', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_EncounterJournal', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_GlyphUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_GMChatUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_GMSurveyUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_GuildBankUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_GuildControlUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_GuildUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_InspectUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_ItemAlterationUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_ItemSocketingUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_LookingForGuildUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_MacroUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_MovePad', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_RaidUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_ReforgingUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_TalentUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_TimeManager', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_TokenUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_TradeSkillUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_TrainerUI', '1276933997');
INSERT INTO `addons` VALUES ('Blizzard_VoidStorageUI', '1276933997');

-- ----------------------------
-- Table structure for arena_team
-- ----------------------------
DROP TABLE IF EXISTS `arena_team`;
CREATE TABLE `arena_team` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `captainGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rating` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `backgroundColor` int(10) unsigned NOT NULL DEFAULT '0',
  `emblemColor` int(10) unsigned NOT NULL DEFAULT '0',
  `borderColor` int(10) unsigned NOT NULL DEFAULT '0',
  `emblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `borderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team
-- ----------------------------

-- ----------------------------
-- Table structure for arena_team_member
-- ----------------------------
DROP TABLE IF EXISTS `arena_team_member`;
CREATE TABLE `arena_team_member` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `personalRating` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`,`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team_member
-- ----------------------------

-- ----------------------------
-- Table structure for auctionhouse
-- ----------------------------
DROP TABLE IF EXISTS `auctionhouse`;
CREATE TABLE `auctionhouse` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `auctioneerguid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemguid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemowner` int(10) unsigned NOT NULL DEFAULT '0',
  `buyoutprice` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `buyguid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastbid` int(10) unsigned NOT NULL DEFAULT '0',
  `startbid` int(10) unsigned NOT NULL DEFAULT '0',
  `deposit` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_guid` (`itemguid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auctionhouse
-- ----------------------------

-- ----------------------------
-- Table structure for auctionhousebot
-- ----------------------------
DROP TABLE IF EXISTS `auctionhousebot`;
CREATE TABLE `auctionhousebot` (
  `auctionhouse` int(11) NOT NULL DEFAULT '0' COMMENT 'mapID of the auctionhouse.',
  `name` char(25) DEFAULT NULL COMMENT 'Text name of the auctionhouse.',
  `minitems` int(11) DEFAULT '0' COMMENT 'This is the minimum number of items you want to keep in the auction house. a 0 here will make it the same as the maximum.',
  `maxitems` int(11) DEFAULT '0' COMMENT 'This is the number of items you want to keep in the auction house.',
  `percentgreytradegoods` int(11) DEFAULT '0' COMMENT 'Sets the percentage of the Grey Trade Goods auction items',
  `percentwhitetradegoods` int(11) DEFAULT '27' COMMENT 'Sets the percentage of the White Trade Goods auction items',
  `percentgreentradegoods` int(11) DEFAULT '12' COMMENT 'Sets the percentage of the Green Trade Goods auction items',
  `percentbluetradegoods` int(11) DEFAULT '10' COMMENT 'Sets the percentage of the Blue Trade Goods auction items',
  `percentpurpletradegoods` int(11) DEFAULT '1' COMMENT 'Sets the percentage of the Purple Trade Goods auction items',
  `percentorangetradegoods` int(11) DEFAULT '0' COMMENT 'Sets the percentage of the Orange Trade Goods auction items',
  `percentyellowtradegoods` int(11) DEFAULT '0' COMMENT 'Sets the percentage of the Yellow Trade Goods auction items',
  `percentgreyitems` int(11) DEFAULT '0' COMMENT 'Sets the percentage of the non trade Grey auction items',
  `percentwhiteitems` int(11) DEFAULT '10' COMMENT 'Sets the percentage of the non trade White auction items',
  `percentgreenitems` int(11) DEFAULT '30' COMMENT 'Sets the percentage of the non trade Green auction items',
  `percentblueitems` int(11) DEFAULT '8' COMMENT 'Sets the percentage of the non trade Blue auction items',
  `percentpurpleitems` int(11) DEFAULT '2' COMMENT 'Sets the percentage of the non trade Purple auction items',
  `percentorangeitems` int(11) DEFAULT '0' COMMENT 'Sets the percentage of the non trade Orange auction items',
  `percentyellowitems` int(11) DEFAULT '0' COMMENT 'Sets the percentage of the non trade Yellow auction items',
  `minpricegrey` int(11) DEFAULT '100' COMMENT 'Minimum price of Grey items (percentage).',
  `maxpricegrey` int(11) DEFAULT '150' COMMENT 'Maximum price of Grey items (percentage).',
  `minpricewhite` int(11) DEFAULT '150' COMMENT 'Minimum price of White items (percentage).',
  `maxpricewhite` int(11) DEFAULT '250' COMMENT 'Maximum price of White items (percentage).',
  `minpricegreen` int(11) DEFAULT '800' COMMENT 'Minimum price of Green items (percentage).',
  `maxpricegreen` int(11) DEFAULT '1400' COMMENT 'Maximum price of Green items (percentage).',
  `minpriceblue` int(11) DEFAULT '1250' COMMENT 'Minimum price of Blue items (percentage).',
  `maxpriceblue` int(11) DEFAULT '1750' COMMENT 'Maximum price of Blue items (percentage).',
  `minpricepurple` int(11) DEFAULT '2250' COMMENT 'Minimum price of Purple items (percentage).',
  `maxpricepurple` int(11) DEFAULT '4550' COMMENT 'Maximum price of Purple items (percentage).',
  `minpriceorange` int(11) DEFAULT '3250' COMMENT 'Minimum price of Orange items (percentage).',
  `maxpriceorange` int(11) DEFAULT '5550' COMMENT 'Maximum price of Orange items (percentage).',
  `minpriceyellow` int(11) DEFAULT '5250' COMMENT 'Minimum price of Yellow items (percentage).',
  `maxpriceyellow` int(11) DEFAULT '6550' COMMENT 'Maximum price of Yellow items (percentage).',
  `minbidpricegrey` int(11) DEFAULT '70' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricegrey` int(11) DEFAULT '100' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricewhite` int(11) DEFAULT '70' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricewhite` int(11) DEFAULT '100' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricegreen` int(11) DEFAULT '80' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricegreen` int(11) DEFAULT '100' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceblue` int(11) DEFAULT '75' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 75',
  `maxbidpriceblue` int(11) DEFAULT '100' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricepurple` int(11) DEFAULT '80' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricepurple` int(11) DEFAULT '100' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceorange` int(11) DEFAULT '80' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceorange` int(11) DEFAULT '100' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceyellow` int(11) DEFAULT '80' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceyellow` int(11) DEFAULT '100' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 100',
  `maxstackgrey` int(11) DEFAULT '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackwhite` int(11) DEFAULT '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackgreen` int(11) DEFAULT '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackblue` int(11) DEFAULT '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackpurple` int(11) DEFAULT '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackorange` int(11) DEFAULT '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackyellow` int(11) DEFAULT '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `buyerpricegrey` int(11) DEFAULT '1' COMMENT 'Multiplier to vendorprice when buying grey items from auctionhouse',
  `buyerpricewhite` int(11) DEFAULT '3' COMMENT 'Multiplier to vendorprice when buying white items from auctionhouse',
  `buyerpricegreen` int(11) DEFAULT '5' COMMENT 'Multiplier to vendorprice when buying green items from auctionhouse',
  `buyerpriceblue` int(11) DEFAULT '12' COMMENT 'Multiplier to vendorprice when buying blue items from auctionhouse',
  `buyerpricepurple` int(11) DEFAULT '15' COMMENT 'Multiplier to vendorprice when buying purple items from auctionhouse',
  `buyerpriceorange` int(11) DEFAULT '20' COMMENT 'Multiplier to vendorprice when buying orange items from auctionhouse',
  `buyerpriceyellow` int(11) DEFAULT '22' COMMENT 'Multiplier to vendorprice when buying yellow items from auctionhouse',
  `buyerbiddinginterval` int(11) DEFAULT '1' COMMENT 'Interval how frequently AHB bids on each AH. Time in minutes',
  `buyerbidsperinterval` int(11) DEFAULT '1' COMMENT 'number of bids to put in per bidding interval',
  PRIMARY KEY (`auctionhouse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auctionhousebot
-- ----------------------------

-- ----------------------------
-- Table structure for bugreport
-- ----------------------------
DROP TABLE IF EXISTS `bugreport`;
CREATE TABLE `bugreport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Debug System';

-- ----------------------------
-- Records of bugreport
-- ----------------------------

-- ----------------------------
-- Table structure for calendar_events
-- ----------------------------
DROP TABLE IF EXISTS `calendar_events`;
CREATE TABLE `calendar_events` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `creator` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '4',
  `dungeon` int(10) NOT NULL DEFAULT '-1',
  `eventtime` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  `time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendar_events
-- ----------------------------

-- ----------------------------
-- Table structure for calendar_invites
-- ----------------------------
DROP TABLE IF EXISTS `calendar_invites`;
CREATE TABLE `calendar_invites` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `event` bigint(20) unsigned NOT NULL DEFAULT '0',
  `invitee` int(10) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `statustime` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `text` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of calendar_invites
-- ----------------------------

-- ----------------------------
-- Table structure for channels
-- ----------------------------
DROP TABLE IF EXISTS `channels`;
CREATE TABLE `channels` (
  `name` varchar(128) NOT NULL,
  `team` int(10) unsigned NOT NULL,
  `announce` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ownership` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `password` varchar(32) DEFAULT NULL,
  `bannedList` text,
  `lastUsed` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`,`team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Channel System';

-- ----------------------------
-- Records of channels
-- ----------------------------

-- ----------------------------
-- Table structure for characters
-- ----------------------------
DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `account` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `name` varchar(12) NOT NULL DEFAULT '0',
  `race` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gender` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `xp` int(10) unsigned NOT NULL DEFAULT '0',
  `money` bigint(20) unsigned NOT NULL DEFAULT '0',
  `playerBytes` int(10) unsigned NOT NULL DEFAULT '0',
  `playerBytes2` int(10) unsigned NOT NULL DEFAULT '0',
  `playerFlags` int(10) unsigned NOT NULL DEFAULT '0',
  `position_x` float NOT NULL DEFAULT '0',
  `position_y` float NOT NULL DEFAULT '0',
  `position_z` float NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0',
  `instance_id` int(10) unsigned NOT NULL DEFAULT '0',
  `instance_mode_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `taximask` text NOT NULL,
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cinematic` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `totaltime` int(10) unsigned NOT NULL DEFAULT '0',
  `leveltime` int(10) unsigned NOT NULL DEFAULT '0',
  `logout_time` int(10) unsigned NOT NULL DEFAULT '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rest_bonus` float NOT NULL DEFAULT '0',
  `resettalents_cost` int(10) unsigned NOT NULL DEFAULT '0',
  `resettalents_time` int(10) unsigned NOT NULL DEFAULT '0',
  `trans_x` float NOT NULL DEFAULT '0',
  `trans_y` float NOT NULL DEFAULT '0',
  `trans_z` float NOT NULL DEFAULT '0',
  `trans_o` float NOT NULL DEFAULT '0',
  `transguid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `extra_flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stable_slots` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `at_login` smallint(5) unsigned NOT NULL DEFAULT '0',
  `zone` smallint(5) unsigned NOT NULL DEFAULT '0',
  `death_expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `taxi_path` text,
  `totalKills` int(10) unsigned NOT NULL DEFAULT '0',
  `todayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `chosenTitle` int(10) unsigned NOT NULL DEFAULT '0',
  `watchedFaction` int(10) unsigned NOT NULL DEFAULT '0',
  `drunk` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `health` int(10) unsigned NOT NULL DEFAULT '0',
  `power1` int(10) unsigned NOT NULL DEFAULT '0',
  `power2` int(10) unsigned NOT NULL DEFAULT '0',
  `power3` int(10) unsigned NOT NULL DEFAULT '0',
  `power4` int(10) unsigned NOT NULL DEFAULT '0',
  `power5` int(10) unsigned NOT NULL DEFAULT '0',
  `latency` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `speccount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `activespec` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `deleteInfos_Account` int(10) unsigned DEFAULT NULL,
  `deleteInfos_Name` varchar(12) DEFAULT NULL,
  `deleteDate` int(10) unsigned DEFAULT NULL,
  `achievementPoint` int(10) NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grantableLevels` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `talentTree` varchar(10) NOT NULL DEFAULT '0 0',
  `guildId` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`),
  KEY `idx_account` (`account`) USING BTREE,
  KEY `idx_online` (`online`) USING BTREE,
  KEY `idx_name` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of characters
-- ----------------------------

-- ----------------------------
-- Table structure for character_account_data
-- ----------------------------
DROP TABLE IF EXISTS `character_account_data`;
CREATE TABLE `character_account_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`guid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_account_data
-- ----------------------------

-- ----------------------------
-- Table structure for character_achievement
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement`;
CREATE TABLE `character_achievement` (
  `guid` int(10) unsigned NOT NULL,
  `achievement` smallint(5) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`achievement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement
-- ----------------------------

-- ----------------------------
-- Table structure for character_achievement_progress
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement_progress`;
CREATE TABLE `character_achievement_progress` (
  `guid` int(10) unsigned NOT NULL,
  `criteria` smallint(5) unsigned NOT NULL,
  `counter` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`criteria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement_progress
-- ----------------------------
INSERT INTO `character_achievement_progress` VALUES ('16', '1540', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1541', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1542', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1543', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1544', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1545', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1546', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1548', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1550', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1551', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1552', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1553', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1554', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1555', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1556', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1557', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1558', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1559', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1560', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1561', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1562', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1563', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1564', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1565', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1566', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1567', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1568', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1573', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1574', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1575', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1576', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1577', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1578', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1579', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1580', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1581', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1582', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1583', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1584', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1585', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1586', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1587', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1588', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1589', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1590', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1591', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1592', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1593', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1594', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1595', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1596', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1597', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1598', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1599', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1600', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1601', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1603', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1604', '1', '1385572908');
INSERT INTO `character_achievement_progress` VALUES ('16', '1605', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1606', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1607', '1', '1385572927');
INSERT INTO `character_achievement_progress` VALUES ('16', '1608', '1', '1385572937');
INSERT INTO `character_achievement_progress` VALUES ('16', '1609', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1610', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1611', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1612', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1613', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1614', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1615', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1616', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1617', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1618', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1619', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1620', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1621', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1622', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1623', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1624', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1625', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1626', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1627', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1628', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1629', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1630', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1631', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1632', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1633', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1634', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1635', '1', '1385572922');
INSERT INTO `character_achievement_progress` VALUES ('16', '1636', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1638', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1639', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1641', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1647', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1648', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1649', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1650', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1651', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1652', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1653', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1654', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1655', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1656', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1657', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1658', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1659', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1667', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1668', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1669', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1670', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1671', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1672', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1673', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1674', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1675', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1679', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1688', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1689', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1690', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1691', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1692', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1693', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1694', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1695', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1696', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1697', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1698', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1699', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1700', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1701', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1702', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1703', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1704', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1705', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1706', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1707', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1708', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1713', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1714', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1715', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1716', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1717', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1718', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1719', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1720', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1721', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1722', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1723', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1724', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1725', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1726', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1727', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1729', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1731', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1732', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1733', '1', '1385572164');
INSERT INTO `character_achievement_progress` VALUES ('16', '1734', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1735', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1736', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1737', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1738', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1739', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1740', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1741', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1742', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1743', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1745', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1746', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1747', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1762', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1763', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1764', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1765', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1766', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1767', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1768', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1770', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1771', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1772', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1773', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1775', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1776', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1777', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1778', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1779', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1780', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1781', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1782', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1783', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1784', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1785', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1786', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1787', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1788', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1789', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1791', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1792', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1793', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1794', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1795', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '1796', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '2020', '200', '1385485131');
INSERT INTO `character_achievement_progress` VALUES ('16', '2044', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '2072', '3292', '1385707452');
INSERT INTO `character_achievement_progress` VALUES ('16', '2104', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '2238', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '2239', '7', '1386322916');
INSERT INTO `character_achievement_progress` VALUES ('16', '2342', '1', '1385485761');
INSERT INTO `character_achievement_progress` VALUES ('16', '2344', '1', '1385485792');
INSERT INTO `character_achievement_progress` VALUES ('16', '2345', '1', '1385485805');
INSERT INTO `character_achievement_progress` VALUES ('16', '2347', '1', '1385485776');
INSERT INTO `character_achievement_progress` VALUES ('16', '2350', '1', '1385485693');
INSERT INTO `character_achievement_progress` VALUES ('16', '2356', '1', '1385485547');
INSERT INTO `character_achievement_progress` VALUES ('16', '2422', '5720', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '3239', '1', '1385575209');
INSERT INTO `character_achievement_progress` VALUES ('16', '3249', '1', '1385573745');
INSERT INTO `character_achievement_progress` VALUES ('16', '3354', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '3355', '895802', '1386322916');
INSERT INTO `character_achievement_progress` VALUES ('16', '3356', '1020', '1385572167');
INSERT INTO `character_achievement_progress` VALUES ('16', '3506', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '3507', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '3510', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '3511', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '3512', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '3513', '895802', '1386322916');
INSERT INTO `character_achievement_progress` VALUES ('16', '3631', '7', '1386322916');
INSERT INTO `character_achievement_progress` VALUES ('16', '3723', '1', '1385485761');
INSERT INTO `character_achievement_progress` VALUES ('16', '3725', '1', '1385485792');
INSERT INTO `character_achievement_progress` VALUES ('16', '3726', '1', '1385485805');
INSERT INTO `character_achievement_progress` VALUES ('16', '3728', '1', '1385485776');
INSERT INTO `character_achievement_progress` VALUES ('16', '3731', '1', '1385485693');
INSERT INTO `character_achievement_progress` VALUES ('16', '3737', '1', '1385485547');
INSERT INTO `character_achievement_progress` VALUES ('16', '3738', '1', '1385571111');
INSERT INTO `character_achievement_progress` VALUES ('16', '3904', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3905', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3906', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3907', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3908', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3909', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3910', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3911', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '3941', '1', '1386498205');
INSERT INTO `character_achievement_progress` VALUES ('16', '3942', '1', '1385572093');
INSERT INTO `character_achievement_progress` VALUES ('16', '3943', '1', '1386425810');
INSERT INTO `character_achievement_progress` VALUES ('16', '3965', '1', '1385575209');
INSERT INTO `character_achievement_progress` VALUES ('16', '3975', '1', '1385573745');
INSERT INTO `character_achievement_progress` VALUES ('16', '4092', '895802', '1386322916');
INSERT INTO `character_achievement_progress` VALUES ('16', '4093', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '4122', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4123', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4124', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4125', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4126', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4127', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4128', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4129', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4130', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4131', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4132', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4134', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4135', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4136', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4137', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4138', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4139', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4140', '1', '1385638441');
INSERT INTO `character_achievement_progress` VALUES ('16', '4141', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4142', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4143', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4144', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4146', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4147', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4148', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4149', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4150', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4151', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4152', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4153', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4154', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4155', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4157', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4158', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4159', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4160', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4162', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4163', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4164', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4165', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4166', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4167', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4168', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4170', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4171', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4172', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4173', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4174', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4175', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4176', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4177', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4178', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4179', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4180', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4181', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4182', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4183', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4184', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4185', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4186', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4187', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4188', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4189', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4190', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4191', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4192', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4193', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4194', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4195', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4196', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4197', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4198', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4199', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4200', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4201', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4202', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4203', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4204', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4205', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4206', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4207', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4208', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4209', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4210', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4211', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4212', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4213', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4214', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4215', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4217', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4218', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4224', '2100000002', '1385485169');
INSERT INTO `character_achievement_progress` VALUES ('16', '4744', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '4745', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '4746', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '4753', '850', '1385622552');
INSERT INTO `character_achievement_progress` VALUES ('16', '4770', '1', '1385485805');
INSERT INTO `character_achievement_progress` VALUES ('16', '4774', '1', '1385485693');
INSERT INTO `character_achievement_progress` VALUES ('16', '4775', '1', '1385485761');
INSERT INTO `character_achievement_progress` VALUES ('16', '4776', '1', '1385485776');
INSERT INTO `character_achievement_progress` VALUES ('16', '4777', '1', '1385485547');
INSERT INTO `character_achievement_progress` VALUES ('16', '4779', '1', '1385485562');
INSERT INTO `character_achievement_progress` VALUES ('16', '4781', '1', '1385485792');
INSERT INTO `character_achievement_progress` VALUES ('16', '4940', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '4943', '1679388717', '1386576932');
INSERT INTO `character_achievement_progress` VALUES ('16', '5212', '85', '1385485153');
INSERT INTO `character_achievement_progress` VALUES ('16', '5221', '85', '1385485153');
INSERT INTO `character_achievement_progress` VALUES ('16', '5238', '85', '1385485153');
INSERT INTO `character_achievement_progress` VALUES ('16', '5290', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5291', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5292', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5293', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5294', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5295', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5296', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5297', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5298', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5301', '13', '1385573341');
INSERT INTO `character_achievement_progress` VALUES ('16', '5305', '1', '1385572167');
INSERT INTO `character_achievement_progress` VALUES ('16', '5313', '1002', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '5314', '1002', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '5315', '1002', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '5316', '6010', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '5317', '3602', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '5322', '850', '1385622552');
INSERT INTO `character_achievement_progress` VALUES ('16', '5324', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '5325', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '5326', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '5327', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '5371', '12861318', '1385622959');
INSERT INTO `character_achievement_progress` VALUES ('16', '5372', '1863637421', '1386576932');
INSERT INTO `character_achievement_progress` VALUES ('16', '5373', '9999999', '1385628689');
INSERT INTO `character_achievement_progress` VALUES ('16', '5374', '98745984', '1385622934');
INSERT INTO `character_achievement_progress` VALUES ('16', '5375', '1863425311', '1386576932');
INSERT INTO `character_achievement_progress` VALUES ('16', '5376', '98745984', '1385622934');
INSERT INTO `character_achievement_progress` VALUES ('16', '5512', '4', '1385485865');
INSERT INTO `character_achievement_progress` VALUES ('16', '5529', '1090', '1386576932');
INSERT INTO `character_achievement_progress` VALUES ('16', '5530', '103', '1386426542');
INSERT INTO `character_achievement_progress` VALUES ('16', '5531', '3', '1385622552');
INSERT INTO `character_achievement_progress` VALUES ('16', '5532', '1', '1385638462');
INSERT INTO `character_achievement_progress` VALUES ('16', '5843', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5844', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5845', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5846', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5847', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5848', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5849', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5850', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5851', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5852', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5853', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5854', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5855', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5856', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5857', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5858', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5859', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5860', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5861', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5862', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5863', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5864', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5865', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5866', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5867', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5868', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5869', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5871', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5872', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5873', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '5874', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '6141', '2', '1385485560');
INSERT INTO `character_achievement_progress` VALUES ('16', '6142', '5', '1385485804');
INSERT INTO `character_achievement_progress` VALUES ('16', '7849', '1', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '8749', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '8819', '500', '1385485131');
INSERT INTO `character_achievement_progress` VALUES ('16', '8820', '500', '1385485131');
INSERT INTO `character_achievement_progress` VALUES ('16', '8821', '500', '1385485131');
INSERT INTO `character_achievement_progress` VALUES ('16', '8822', '500', '1385485131');
INSERT INTO `character_achievement_progress` VALUES ('16', '9378', '1', '1385485131');
INSERT INTO `character_achievement_progress` VALUES ('16', '9598', '85', '1385485153');
INSERT INTO `character_achievement_progress` VALUES ('16', '9619', '1', '1385485352');
INSERT INTO `character_achievement_progress` VALUES ('16', '9683', '1002', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '9684', '1002', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '9685', '3602', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '9686', '1002', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '9687', '6010', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '9818', '1', '1386148997');
INSERT INTO `character_achievement_progress` VALUES ('16', '11279', '2860', '1386576861');
INSERT INTO `character_achievement_progress` VALUES ('16', '12698', '1035', '1386498205');
INSERT INTO `character_achievement_progress` VALUES ('16', '13498', '85', '1385485153');
INSERT INTO `character_achievement_progress` VALUES ('16', '13594', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13595', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13596', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13597', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13598', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13600', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13609', '2', '1386322916');
INSERT INTO `character_achievement_progress` VALUES ('16', '13780', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13795', '1', '1385485901');
INSERT INTO `character_achievement_progress` VALUES ('16', '13796', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13797', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13799', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13800', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13801', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13802', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '13803', '1', '1385485898');
INSERT INTO `character_achievement_progress` VALUES ('16', '13804', '1', '1385485895');
INSERT INTO `character_achievement_progress` VALUES ('16', '13805', '1', '1385485886');
INSERT INTO `character_achievement_progress` VALUES ('16', '14037', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14038', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14039', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14040', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14041', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14042', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14043', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14044', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14046', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14047', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14048', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14049', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14050', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14051', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14052', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14053', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14054', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14055', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14056', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14057', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14058', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14060', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14061', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14062', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14063', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14064', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14066', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14067', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14068', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14069', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14070', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14071', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14072', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14073', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14074', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14075', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14076', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14077', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14078', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14079', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14086', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14087', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14088', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14089', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14090', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14091', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14092', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14093', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14094', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14095', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14096', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14099', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14100', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14101', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14102', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14103', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14104', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14105', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14106', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14107', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14108', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14109', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14110', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14111', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14112', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14113', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14114', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14115', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14116', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14117', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14118', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14119', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14120', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14121', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14122', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14123', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14124', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14125', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14126', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14127', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14129', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14130', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14131', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14132', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14133', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14134', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14135', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14136', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14137', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14138', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14139', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14140', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14141', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14142', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14143', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14144', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14145', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14147', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14148', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14149', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14150', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14151', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14153', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14154', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14155', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14156', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14157', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14158', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14159', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14160', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14161', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14162', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14163', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14164', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14165', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14166', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14167', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14168', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14169', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14170', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '14174', '85', '1385485153');
INSERT INTO `character_achievement_progress` VALUES ('16', '14183', '85', '1385485153');
INSERT INTO `character_achievement_progress` VALUES ('16', '14382', '1', '1385624390');
INSERT INTO `character_achievement_progress` VALUES ('16', '14384', '1', '1385624390');
INSERT INTO `character_achievement_progress` VALUES ('16', '15106', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15107', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15108', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15109', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15110', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15111', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15112', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15113', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15114', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15115', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15116', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15117', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15118', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15119', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15120', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15121', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15122', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15123', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15124', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15125', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15126', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15127', '1', '1386321234');
INSERT INTO `character_achievement_progress` VALUES ('16', '15128', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15129', '1', '1386321256');
INSERT INTO `character_achievement_progress` VALUES ('16', '15130', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15131', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15132', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15133', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15139', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15140', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15141', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15142', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15143', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15144', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15145', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15146', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15147', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15148', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15149', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15150', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15151', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15152', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15153', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15154', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15155', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15156', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15157', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15158', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15159', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15160', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15161', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15162', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15163', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15164', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15165', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15166', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15167', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15168', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15169', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15170', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15171', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15172', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15173', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15174', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15175', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15176', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15177', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15178', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15179', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15180', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15181', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15182', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15183', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15184', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15185', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15186', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15187', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '15330', '1', '1385485761');
INSERT INTO `character_achievement_progress` VALUES ('16', '15332', '1', '1385485792');
INSERT INTO `character_achievement_progress` VALUES ('16', '15333', '1', '1385485805');
INSERT INTO `character_achievement_progress` VALUES ('16', '15335', '1', '1385485776');
INSERT INTO `character_achievement_progress` VALUES ('16', '15338', '1', '1385485693');
INSERT INTO `character_achievement_progress` VALUES ('16', '15344', '1', '1385485547');
INSERT INTO `character_achievement_progress` VALUES ('16', '15346', '1', '1385485761');
INSERT INTO `character_achievement_progress` VALUES ('16', '15348', '1', '1385485792');
INSERT INTO `character_achievement_progress` VALUES ('16', '15349', '1', '1385485805');
INSERT INTO `character_achievement_progress` VALUES ('16', '15351', '1', '1385485776');
INSERT INTO `character_achievement_progress` VALUES ('16', '15354', '1', '1385485693');
INSERT INTO `character_achievement_progress` VALUES ('16', '15360', '1', '1385485547');
INSERT INTO `character_achievement_progress` VALUES ('16', '15361', '1', '1385571111');
INSERT INTO `character_achievement_progress` VALUES ('16', '15688', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '15689', '477127', '1386576918');
INSERT INTO `character_achievement_progress` VALUES ('16', '16047', '1', '1385623584');
INSERT INTO `character_achievement_progress` VALUES ('16', '16048', '1', '1385625543');
INSERT INTO `character_achievement_progress` VALUES ('16', '16058', '1', '1385624390');
INSERT INTO `character_achievement_progress` VALUES ('16', '16066', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '16081', '1', '1385623584');
INSERT INTO `character_achievement_progress` VALUES ('16', '16085', '1', '1385625543');
INSERT INTO `character_achievement_progress` VALUES ('16', '16086', '1', '1385624390');
INSERT INTO `character_achievement_progress` VALUES ('16', '16089', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '16092', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '16093', '1', '1386355957');
INSERT INTO `character_achievement_progress` VALUES ('16', '16419', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '16421', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '16422', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '16423', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '16424', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '16425', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '16426', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('16', '16580', '4', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '16636', '4', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '16790', '2', '1385624727');
INSERT INTO `character_achievement_progress` VALUES ('16', '16820', '895802', '1386322916');
INSERT INTO `character_achievement_progress` VALUES ('16', '16825', '3602', '1385572106');
INSERT INTO `character_achievement_progress` VALUES ('16', '18524', '1', '1386498205');
INSERT INTO `character_achievement_progress` VALUES ('16', '18525', '3', '1385624727');
INSERT INTO `character_achievement_progress` VALUES ('16', '18526', '1', '1386425810');
INSERT INTO `character_achievement_progress` VALUES ('16', '18672', '2', '1385634247');
INSERT INTO `character_achievement_progress` VALUES ('20', '34', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '35', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '36', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '37', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '38', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '39', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '40', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '41', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '167', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '641', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '651', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '652', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '653', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '654', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '656', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '657', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '753', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '754', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '755', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '756', '1', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '992', '3100', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '993', '4000', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '994', '500', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '995', '3100', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '996', '400', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '2020', '200', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '5212', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '5218', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '5236', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '5301', '7', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '5313', '3100', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '5314', '3100', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '5315', '4000', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '5316', '500', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '5317', '400', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '8819', '500', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '8820', '500', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '8821', '500', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '8822', '500', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '9598', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '9683', '3100', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '9684', '3100', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '9685', '400', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '9686', '4000', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '9687', '500', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('20', '12698', '90', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '13498', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '14174', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '14179', '85', '1386260690');
INSERT INTO `character_achievement_progress` VALUES ('20', '16825', '3100', '1386260642');
INSERT INTO `character_achievement_progress` VALUES ('25', '34', '10', '1386923149');
INSERT INTO `character_achievement_progress` VALUES ('25', '35', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '36', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '37', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '38', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '39', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '40', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '41', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '73', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '162', '23990360', '1386954044');
INSERT INTO `character_achievement_progress` VALUES ('25', '167', '1', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '230', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '231', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '232', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '233', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '234', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '236', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '653', '1', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '657', '1', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '753', '1', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '756', '1', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '757', '1', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '822', '1', '1386921933');
INSERT INTO `character_achievement_progress` VALUES ('25', '826', '1', '1386923109');
INSERT INTO `character_achievement_progress` VALUES ('25', '829', '1', '1386923544');
INSERT INTO `character_achievement_progress` VALUES ('25', '992', '4700', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '993', '3274', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '994', '674', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '995', '3274', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '996', '574', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '1007', '10', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '1043', '1', '1386923859');
INSERT INTO `character_achievement_progress` VALUES ('25', '2020', '200', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '2046', '10', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '2239', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '2416', '3000', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '3354', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '3355', '12600', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '3506', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '3507', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '3510', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '3511', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '3512', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '3513', '12600', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '3631', '3', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '4092', '12600', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '4093', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '4125', '1', '1386953549');
INSERT INTO `character_achievement_progress` VALUES ('25', '4224', '4294967111', '1386924793');
INSERT INTO `character_achievement_progress` VALUES ('25', '4742', '3000', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '4751', '10', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '5018', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '5042', '1', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '5212', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '5235', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '5289', '1', '1386923030');
INSERT INTO `character_achievement_progress` VALUES ('25', '5301', '8', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '5313', '3274', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '5314', '4700', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '5315', '3274', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '5316', '674', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '5317', '574', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '5371', '764', '1386953622');
INSERT INTO `character_achievement_progress` VALUES ('25', '5372', '39754', '1386954048');
INSERT INTO `character_achievement_progress` VALUES ('25', '5373', '99999', '1386922648');
INSERT INTO `character_achievement_progress` VALUES ('25', '5529', '279', '1386954044');
INSERT INTO `character_achievement_progress` VALUES ('25', '5530', '261', '1386923654');
INSERT INTO `character_achievement_progress` VALUES ('25', '5532', '18', '1386954044');
INSERT INTO `character_achievement_progress` VALUES ('25', '8819', '500', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '8820', '500', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '8821', '500', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '8822', '500', '1386921855');
INSERT INTO `character_achievement_progress` VALUES ('25', '9598', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '9619', '1', '1386924773');
INSERT INTO `character_achievement_progress` VALUES ('25', '9683', '4700', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '9684', '3274', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '9685', '574', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '9686', '3274', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '9687', '674', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '12698', '100', '1386924773');
INSERT INTO `character_achievement_progress` VALUES ('25', '13498', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '14042', '1', '1386923359');
INSERT INTO `character_achievement_progress` VALUES ('25', '14087', '1', '1386923359');
INSERT INTO `character_achievement_progress` VALUES ('25', '14174', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '14181', '85', '1386923195');
INSERT INTO `character_achievement_progress` VALUES ('25', '15688', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '15689', '2', '1386922342');
INSERT INTO `character_achievement_progress` VALUES ('25', '16463', '1', '1386922769');
INSERT INTO `character_achievement_progress` VALUES ('25', '16465', '2', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('25', '16820', '12600', '1386925374');
INSERT INTO `character_achievement_progress` VALUES ('25', '16825', '3274', '1386923014');
INSERT INTO `character_achievement_progress` VALUES ('27', '34', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '35', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '36', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '37', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '38', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '39', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '40', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '41', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '167', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '653', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '655', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '656', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '657', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '756', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '834', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '992', '3100', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '993', '4000', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '994', '500', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '995', '3100', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '996', '400', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '2020', '200', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '2045', '2000', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5212', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5214', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5236', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5301', '7', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5313', '3100', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5314', '3100', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5315', '4000', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5316', '500', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '5317', '400', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '8819', '500', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '8820', '500', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '8821', '500', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '8822', '500', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '9598', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '9683', '3100', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '9684', '3100', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '9685', '400', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '9686', '4000', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '9687', '500', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '13498', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '14174', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '14175', '1', '1387017862');
INSERT INTO `character_achievement_progress` VALUES ('27', '16825', '3100', '1387017862');

-- ----------------------------
-- Table structure for character_action
-- ----------------------------
DROP TABLE IF EXISTS `character_action`;
CREATE TABLE `character_action` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `spec` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `button` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `action` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spec`,`button`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_action
-- ----------------------------

-- ----------------------------
-- Table structure for character_arena_stats
-- ----------------------------
DROP TABLE IF EXISTS `character_arena_stats`;
CREATE TABLE `character_arena_stats` (
  `guid` int(10) NOT NULL,
  `slot` tinyint(3) NOT NULL,
  `matchMakerRating` smallint(5) NOT NULL,
  PRIMARY KEY (`guid`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_arena_stats
-- ----------------------------

-- ----------------------------
-- Table structure for character_aura
-- ----------------------------
DROP TABLE IF EXISTS `character_aura`;
CREATE TABLE `character_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effect_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculate_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackcount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` int(11) NOT NULL DEFAULT '0',
  `amount1` int(11) NOT NULL DEFAULT '0',
  `amount2` int(11) NOT NULL DEFAULT '0',
  `base_amount0` int(11) NOT NULL DEFAULT '0',
  `base_amount1` int(11) NOT NULL DEFAULT '0',
  `base_amount2` int(11) NOT NULL DEFAULT '0',
  `maxduration` int(11) NOT NULL DEFAULT '0',
  `remaintime` int(11) NOT NULL DEFAULT '0',
  `remaincharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`caster_guid`,`item_guid`,`spell`,`effect_mask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_aura
-- ----------------------------

-- ----------------------------
-- Table structure for character_banned
-- ----------------------------
DROP TABLE IF EXISTS `character_banned`;
CREATE TABLE `character_banned` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`bandate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Ban List';

-- ----------------------------
-- Records of character_banned
-- ----------------------------

-- ----------------------------
-- Table structure for character_battleground_data
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_data`;
CREATE TABLE `character_battleground_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `instanceId` int(10) unsigned NOT NULL COMMENT 'Instance Identifier',
  `team` smallint(5) unsigned NOT NULL,
  `joinX` float NOT NULL DEFAULT '0',
  `joinY` float NOT NULL DEFAULT '0',
  `joinZ` float NOT NULL DEFAULT '0',
  `joinO` float NOT NULL DEFAULT '0',
  `joinMapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `taxiStart` int(10) unsigned NOT NULL DEFAULT '0',
  `taxiEnd` int(10) unsigned NOT NULL DEFAULT '0',
  `mountSpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_battleground_data
-- ----------------------------

-- ----------------------------
-- Table structure for character_battleground_random
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_random`;
CREATE TABLE `character_battleground_random` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_battleground_random
-- ----------------------------

-- ----------------------------
-- Table structure for character_bug_submission
-- ----------------------------
DROP TABLE IF EXISTS `character_bug_submission`;
CREATE TABLE `character_bug_submission` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `content` varchar(500) DEFAULT NULL,
  `playerId` bigint(20) DEFAULT NULL,
  `position_x` float DEFAULT NULL,
  `position_y` float DEFAULT NULL,
  `position_z` float DEFAULT NULL,
  `orientation` float DEFAULT NULL,
  `mapId` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_bug_submission
-- ----------------------------

-- ----------------------------
-- Table structure for character_cuf_profiles
-- ----------------------------
DROP TABLE IF EXISTS `character_cuf_profiles`;
CREATE TABLE `character_cuf_profiles` (
  `guid` int(10) unsigned NOT NULL COMMENT 'Character Guid',
  `id` tinyint(3) unsigned NOT NULL COMMENT 'Profile Id (0-4)',
  `name` varchar(12) NOT NULL COMMENT 'Profile Name',
  `frameHeight` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Frame Height',
  `frameWidth` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Frame Width',
  `sortBy` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Frame Sort By',
  `healthText` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Frame Health Text',
  `boolOptions` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Many Configurable Bool Options',
  `unk146` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Unk Int8',
  `unk147` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Unk Int8',
  `unk148` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Unk Int8',
  `unk150` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Unk Int16',
  `unk152` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Unk Int16',
  `unk154` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Profile Unk Int16',
  PRIMARY KEY (`guid`,`id`),
  KEY `index` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_cuf_profiles
-- ----------------------------

-- ----------------------------
-- Table structure for character_currency
-- ----------------------------
DROP TABLE IF EXISTS `character_currency`;
CREATE TABLE `character_currency` (
  `guid` int(10) unsigned NOT NULL,
  `currency` smallint(5) unsigned NOT NULL,
  `total_count` int(10) unsigned NOT NULL,
  `week_count` int(10) unsigned NOT NULL,
  `week_cap` int(10) unsigned NOT NULL,
  `new_cap` int(10) unsigned NOT NULL,
  PRIMARY KEY (`guid`,`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_currency
-- ----------------------------

-- ----------------------------
-- Table structure for character_current_artifacts
-- ----------------------------
DROP TABLE IF EXISTS `character_current_artifacts`;
CREATE TABLE `character_current_artifacts` (
  `guid` int(10) unsigned NOT NULL,
  `branchId` int(10) NOT NULL DEFAULT '0',
  `entry` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`branchId`,`entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_current_artifacts
-- ----------------------------

-- ----------------------------
-- Table structure for character_declinedname
-- ----------------------------
DROP TABLE IF EXISTS `character_declinedname`;
CREATE TABLE `character_declinedname` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL DEFAULT '',
  `dative` varchar(15) NOT NULL DEFAULT '',
  `accusative` varchar(15) NOT NULL DEFAULT '',
  `instrumental` varchar(15) NOT NULL DEFAULT '',
  `prepositional` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for character_digsites
-- ----------------------------
DROP TABLE IF EXISTS `character_digsites`;
CREATE TABLE `character_digsites` (
  `guid` int(10) unsigned NOT NULL,
  `entry` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_digsites
-- ----------------------------

-- ----------------------------
-- Table structure for character_equipmentsets
-- ----------------------------
DROP TABLE IF EXISTS `character_equipmentsets`;
CREATE TABLE `character_equipmentsets` (
  `guid` int(10) NOT NULL DEFAULT '0',
  `setguid` bigint(20) NOT NULL AUTO_INCREMENT,
  `setindex` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(31) NOT NULL,
  `iconname` varchar(100) NOT NULL,
  `ignore_mask` int(11) unsigned NOT NULL DEFAULT '0',
  `item0` int(11) unsigned NOT NULL DEFAULT '0',
  `item1` int(11) unsigned NOT NULL DEFAULT '0',
  `item2` int(11) unsigned NOT NULL DEFAULT '0',
  `item3` int(11) unsigned NOT NULL DEFAULT '0',
  `item4` int(11) unsigned NOT NULL DEFAULT '0',
  `item5` int(11) unsigned NOT NULL DEFAULT '0',
  `item6` int(11) unsigned NOT NULL DEFAULT '0',
  `item7` int(11) unsigned NOT NULL DEFAULT '0',
  `item8` int(11) unsigned NOT NULL DEFAULT '0',
  `item9` int(11) unsigned NOT NULL DEFAULT '0',
  `item10` int(11) unsigned NOT NULL DEFAULT '0',
  `item11` int(11) unsigned NOT NULL DEFAULT '0',
  `item12` int(11) unsigned NOT NULL DEFAULT '0',
  `item13` int(11) unsigned NOT NULL DEFAULT '0',
  `item14` int(11) unsigned NOT NULL DEFAULT '0',
  `item15` int(11) unsigned NOT NULL DEFAULT '0',
  `item16` int(11) unsigned NOT NULL DEFAULT '0',
  `item17` int(11) unsigned NOT NULL DEFAULT '0',
  `item18` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`setguid`),
  UNIQUE KEY `idx_set` (`guid`,`setguid`,`setindex`) USING BTREE,
  KEY `Idx_setindex` (`setindex`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_equipmentsets
-- ----------------------------

-- ----------------------------
-- Table structure for character_gifts
-- ----------------------------
DROP TABLE IF EXISTS `character_gifts`;
CREATE TABLE `character_gifts` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`),
  KEY `idx_guid` (`guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_gifts
-- ----------------------------

-- ----------------------------
-- Table structure for character_glyphs
-- ----------------------------
DROP TABLE IF EXISTS `character_glyphs`;
CREATE TABLE `character_glyphs` (
  `guid` int(10) unsigned NOT NULL,
  `spec` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `glyph1` smallint(5) unsigned DEFAULT '0',
  `glyph2` smallint(5) unsigned DEFAULT '0',
  `glyph3` smallint(5) unsigned DEFAULT '0',
  `glyph4` smallint(5) unsigned DEFAULT '0',
  `glyph5` smallint(5) unsigned DEFAULT '0',
  `glyph6` smallint(5) unsigned DEFAULT '0',
  `glyph7` smallint(5) unsigned DEFAULT '0',
  `glyph8` smallint(5) unsigned DEFAULT '0',
  `glyph9` smallint(5) unsigned DEFAULT '0',
  PRIMARY KEY (`guid`,`spec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_glyphs
-- ----------------------------

-- ----------------------------
-- Table structure for character_homebind
-- ----------------------------
DROP TABLE IF EXISTS `character_homebind`;
CREATE TABLE `character_homebind` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `zoneId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_homebind
-- ----------------------------

-- ----------------------------
-- Table structure for character_instance
-- ----------------------------
DROP TABLE IF EXISTS `character_instance`;
CREATE TABLE `character_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_instance
-- ----------------------------

-- ----------------------------
-- Table structure for character_inventory
-- ----------------------------
DROP TABLE IF EXISTS `character_inventory`;
CREATE TABLE `character_inventory` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bag` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Global Unique Identifier',
  PRIMARY KEY (`item`),
  KEY `idx_guid` (`guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_inventory
-- ----------------------------

-- ----------------------------
-- Table structure for character_pet
-- ----------------------------
DROP TABLE IF EXISTS `character_pet`;
CREATE TABLE `character_pet` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `modelid` int(10) unsigned DEFAULT '0',
  `CreatedBySpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `PetType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` smallint(5) unsigned NOT NULL DEFAULT '1',
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `Reactstate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(21) NOT NULL DEFAULT 'Pet',
  `renamed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `curhealth` int(10) unsigned NOT NULL DEFAULT '1',
  `curmana` int(10) unsigned NOT NULL DEFAULT '0',
  `savetime` int(10) unsigned NOT NULL DEFAULT '0',
  `abdata` text,
  PRIMARY KEY (`id`),
  KEY `owner` (`owner`) USING BTREE,
  KEY `idx_slot` (`slot`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';

-- ----------------------------
-- Records of character_pet
-- ----------------------------

-- ----------------------------
-- Table structure for character_pet_declinedname
-- ----------------------------
DROP TABLE IF EXISTS `character_pet_declinedname`;
CREATE TABLE `character_pet_declinedname` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `genitive` varchar(12) NOT NULL DEFAULT '',
  `dative` varchar(12) NOT NULL DEFAULT '',
  `accusative` varchar(12) NOT NULL DEFAULT '',
  `instrumental` varchar(12) NOT NULL DEFAULT '',
  `prepositional` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `owner_key` (`owner`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_pet_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for character_queststatus
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus`;
CREATE TABLE `character_queststatus` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `explored` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timer` int(10) unsigned NOT NULL DEFAULT '0',
  `mobcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playercount` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus
-- ----------------------------

-- ----------------------------
-- Table structure for character_queststatus_daily
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_daily`;
CREATE TABLE `character_queststatus_daily` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_daily
-- ----------------------------

-- ----------------------------
-- Table structure for character_queststatus_monthly
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_monthly`;
CREATE TABLE `character_queststatus_monthly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_monthly
-- ----------------------------

-- ----------------------------
-- Table structure for character_queststatus_rewarded
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_rewarded`;
CREATE TABLE `character_queststatus_rewarded` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `active` tinyint(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_rewarded
-- ----------------------------

-- ----------------------------
-- Table structure for character_queststatus_seasonal
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_seasonal`;
CREATE TABLE `character_queststatus_seasonal` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `event` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_seasonal
-- ----------------------------

-- ----------------------------
-- Table structure for character_queststatus_weekly
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_weekly`;
CREATE TABLE `character_queststatus_weekly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_weekly
-- ----------------------------

-- ----------------------------
-- Table structure for character_reputation
-- ----------------------------
DROP TABLE IF EXISTS `character_reputation`;
CREATE TABLE `character_reputation` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `faction` smallint(5) unsigned NOT NULL DEFAULT '0',
  `standing` int(11) NOT NULL DEFAULT '0',
  `flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_reputation
-- ----------------------------

-- ----------------------------
-- Table structure for character_skills
-- ----------------------------
DROP TABLE IF EXISTS `character_skills`;
CREATE TABLE `character_skills` (
  `guid` int(10) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` smallint(5) unsigned NOT NULL,
  `value` smallint(5) unsigned NOT NULL,
  `max` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`guid`,`skill`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_skills
-- ----------------------------

-- ----------------------------
-- Table structure for character_social
-- ----------------------------
DROP TABLE IF EXISTS `character_social`;
CREATE TABLE `character_social` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL DEFAULT '' COMMENT 'Friend Note',
  PRIMARY KEY (`guid`,`friend`,`flags`),
  KEY `friend` (`friend`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_social
-- ----------------------------

-- ----------------------------
-- Table structure for character_spell
-- ----------------------------
DROP TABLE IF EXISTS `character_spell`;
CREATE TABLE `character_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of character_spell
-- ----------------------------

-- ----------------------------
-- Table structure for character_spell_cooldown
-- ----------------------------
DROP TABLE IF EXISTS `character_spell_cooldown`;
CREATE TABLE `character_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for character_stats
-- ----------------------------
DROP TABLE IF EXISTS `character_stats`;
CREATE TABLE `character_stats` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower1` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower2` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower3` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower4` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower5` int(10) unsigned NOT NULL DEFAULT '0',
  `strength` int(10) unsigned NOT NULL DEFAULT '0',
  `agility` int(10) unsigned NOT NULL DEFAULT '0',
  `stamina` int(10) unsigned NOT NULL DEFAULT '0',
  `intellect` int(10) unsigned NOT NULL DEFAULT '0',
  `spirit` int(10) unsigned NOT NULL DEFAULT '0',
  `armor` int(10) unsigned NOT NULL DEFAULT '0',
  `resHoly` int(10) unsigned NOT NULL DEFAULT '0',
  `resFire` int(10) unsigned NOT NULL DEFAULT '0',
  `resNature` int(10) unsigned NOT NULL DEFAULT '0',
  `resFrost` int(10) unsigned NOT NULL DEFAULT '0',
  `resShadow` int(10) unsigned NOT NULL DEFAULT '0',
  `resArcane` int(10) unsigned NOT NULL DEFAULT '0',
  `blockPct` float unsigned NOT NULL DEFAULT '0',
  `dodgePct` float unsigned NOT NULL DEFAULT '0',
  `parryPct` float unsigned NOT NULL DEFAULT '0',
  `critPct` float unsigned NOT NULL DEFAULT '0',
  `rangedCritPct` float unsigned NOT NULL DEFAULT '0',
  `spellCritPct` float unsigned NOT NULL DEFAULT '0',
  `attackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `rangedAttackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `spellPower` int(10) unsigned NOT NULL DEFAULT '0',
  `resilience` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_stats
-- ----------------------------

-- ----------------------------
-- Table structure for character_talent
-- ----------------------------
DROP TABLE IF EXISTS `character_talent`;
CREATE TABLE `character_talent` (
  `guid` int(10) unsigned NOT NULL,
  `spell` mediumint(8) unsigned NOT NULL,
  `spec` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`,`spec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_talent
-- ----------------------------

-- ----------------------------
-- Table structure for character_void_storage
-- ----------------------------
DROP TABLE IF EXISTS `character_void_storage`;
CREATE TABLE `character_void_storage` (
  `itemId` bigint(20) unsigned NOT NULL,
  `playerGuid` int(10) unsigned NOT NULL,
  `itemEntry` mediumint(8) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `creatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `randomProperty` int(10) unsigned NOT NULL DEFAULT '0',
  `suffixFactor` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemId`),
  UNIQUE KEY `idx_player_slot` (`playerGuid`,`slot`) USING BTREE,
  KEY `idx_player` (`playerGuid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_void_storage
-- ----------------------------

-- ----------------------------
-- Table structure for corpse
-- ----------------------------
DROP TABLE IF EXISTS `corpse`;
CREATE TABLE `corpse` (
  `corpseGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `phaseMask` smallint(5) unsigned NOT NULL DEFAULT '1',
  `displayId` int(10) unsigned NOT NULL DEFAULT '0',
  `itemCache` text NOT NULL,
  `bytes1` int(10) unsigned NOT NULL DEFAULT '0',
  `bytes2` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dynFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `corpseType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`corpseGuid`),
  KEY `idx_type` (`corpseType`) USING BTREE,
  KEY `idx_time` (`time`) USING BTREE,
  KEY `idx_player` (`guid`) USING BTREE,
  KEY `idx_instance` (`instanceId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Death System';

-- ----------------------------
-- Records of corpse
-- ----------------------------

-- ----------------------------
-- Table structure for creature_respawn
-- ----------------------------
DROP TABLE IF EXISTS `creature_respawn`;
CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` int(10) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';

-- ----------------------------
-- Records of creature_respawn
-- ----------------------------
INSERT INTO `creature_respawn` VALUES ('3082', '1383847109', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3083', '1383847059', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3086', '1383847065', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3088', '1383847075', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3089', '1383847080', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3090', '1383847057', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3091', '1383847060', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3214', '1381347288', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3223', '1383847065', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3224', '1383847059', '0', '0');
INSERT INTO `creature_respawn` VALUES ('3225', '1383847065', '0', '0');
INSERT INTO `creature_respawn` VALUES ('7990', '1383847075', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8021', '1386925023', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8034', '1375429455', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8038', '1375429404', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8041', '1375427890', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8046', '1375429149', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8048', '1375427885', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8080', '1376050533', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8089', '1375429156', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8349', '1380190147', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8526', '1385628693', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8538', '1384708823', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8774', '1384710378', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8801', '1384709009', '0', '0');
INSERT INTO `creature_respawn` VALUES ('8965', '1374339816', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9350', '1376052152', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9351', '1376052170', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9462', '1381329551', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9467', '1381329534', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9469', '1381329481', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9474', '1381329520', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9477', '1381329542', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9525', '1375429031', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9534', '1374762434', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9542', '1374763490', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9675', '1380190520', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9678', '1380190541', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9919', '1380190534', '0', '0');
INSERT INTO `creature_respawn` VALUES ('9959', '1380190592', '0', '0');
INSERT INTO `creature_respawn` VALUES ('10589', '1383244709', '0', '0');
INSERT INTO `creature_respawn` VALUES ('11334', '1380190150', '0', '0');
INSERT INTO `creature_respawn` VALUES ('11335', '1380190153', '0', '0');
INSERT INTO `creature_respawn` VALUES ('11336', '1380190151', '0', '0');
INSERT INTO `creature_respawn` VALUES ('11339', '1380190184', '0', '0');
INSERT INTO `creature_respawn` VALUES ('11770', '1380190184', '0', '0');
INSERT INTO `creature_respawn` VALUES ('11781', '1380190155', '0', '0');
INSERT INTO `creature_respawn` VALUES ('12065', '1381217723', '0', '0');
INSERT INTO `creature_respawn` VALUES ('12686', '1375430899', '0', '0');
INSERT INTO `creature_respawn` VALUES ('12844', '1381214399', '0', '0');
INSERT INTO `creature_respawn` VALUES ('12845', '1381214401', '0', '0');
INSERT INTO `creature_respawn` VALUES ('13456', '1384501261', '0', '0');
INSERT INTO `creature_respawn` VALUES ('14793', '1385732870', '0', '0');
INSERT INTO `creature_respawn` VALUES ('16506', '1380190697', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18520', '1383245177', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18806', '1386575479', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18821', '1386082433', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18822', '1386575488', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18830', '1386575506', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18837', '1374398720', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18838', '1374398724', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18841', '1386575512', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18864', '1385902258', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18877', '1386575461', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18891', '1386575430', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18895', '1386575437', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18905', '1374398721', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18924', '1386575352', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18934', '1386575420', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18944', '1386082430', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18972', '1386575452', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18974', '1386924038', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18980', '1386082430', '0', '0');
INSERT INTO `creature_respawn` VALUES ('18986', '1386575507', '0', '0');
INSERT INTO `creature_respawn` VALUES ('19033', '1375451630', '0', '0');
INSERT INTO `creature_respawn` VALUES ('19038', '1375451624', '0', '0');
INSERT INTO `creature_respawn` VALUES ('19660', '1383847090', '0', '0');
INSERT INTO `creature_respawn` VALUES ('19806', '1375427907', '0', '0');
INSERT INTO `creature_respawn` VALUES ('19863', '1375451546', '0', '0');
INSERT INTO `creature_respawn` VALUES ('21163', '1375461943', '0', '0');
INSERT INTO `creature_respawn` VALUES ('21164', '1375461991', '0', '0');
INSERT INTO `creature_respawn` VALUES ('21170', '1375461997', '0', '0');
INSERT INTO `creature_respawn` VALUES ('21173', '1375461932', '0', '0');
INSERT INTO `creature_respawn` VALUES ('21364', '1375460417', '0', '0');
INSERT INTO `creature_respawn` VALUES ('21426', '1375458580', '0', '0');
INSERT INTO `creature_respawn` VALUES ('21933', '1380190516', '0', '0');
INSERT INTO `creature_respawn` VALUES ('22193', '1375461645', '0', '0');
INSERT INTO `creature_respawn` VALUES ('22378', '1375462213', '0', '0');
INSERT INTO `creature_respawn` VALUES ('22761', '1375461991', '0', '0');
INSERT INTO `creature_respawn` VALUES ('22968', '1375461880', '0', '0');
INSERT INTO `creature_respawn` VALUES ('23141', '1375461991', '0', '0');
INSERT INTO `creature_respawn` VALUES ('23204', '1384709005', '0', '0');
INSERT INTO `creature_respawn` VALUES ('23219', '1384709088', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24061', '1385567462', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24070', '1375451644', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24085', '1375432240', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24119', '1385628725', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24208', '1385567453', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24234', '1385628712', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24266', '1385628680', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24375', '1385628740', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24384', '1375451690', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24423', '1384708830', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24428', '1385628705', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24634', '1385628681', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24644', '1385628674', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24656', '1375439354', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24693', '1385567444', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24747', '1384708824', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24763', '1385628671', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24776', '1375449886', '0', '0');
INSERT INTO `creature_respawn` VALUES ('24912', '1376052166', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25016', '1385567760', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25121', '1376052146', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25292', '1376052142', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25392', '1376052559', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25574', '1376052156', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25720', '1376052165', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25756', '1376052142', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25890', '1375451686', '0', '0');
INSERT INTO `creature_respawn` VALUES ('25922', '1376050792', '0', '0');
INSERT INTO `creature_respawn` VALUES ('26028', '1385628687', '0', '0');
INSERT INTO `creature_respawn` VALUES ('26045', '1385567761', '0', '0');
INSERT INTO `creature_respawn` VALUES ('26090', '1385567764', '0', '0');
INSERT INTO `creature_respawn` VALUES ('27057', '1385706925', '0', '0');
INSERT INTO `creature_respawn` VALUES ('27670', '1385706923', '0', '0');
INSERT INTO `creature_respawn` VALUES ('29664', '1386579260', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30011', '1376119105', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30018', '1376118387', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30072', '1384710363', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30074', '1385706882', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30231', '1376118993', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30363', '1375428470', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30519', '1380187887', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30787', '1386575881', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30800', '1386576081', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30867', '1386576092', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30905', '1386575908', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30931', '1386575875', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30943', '1386575500', '0', '0');
INSERT INTO `creature_respawn` VALUES ('30946', '1386575947', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31001', '1386575582', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31015', '1386576036', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31077', '1386576048', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31108', '1386575917', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31136', '1386576096', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31144', '1386575975', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31151', '1386575974', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31180', '1386575145', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31185', '1386576087', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31187', '1386575551', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31191', '1386575965', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31323', '1386575980', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31345', '1386575929', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31385', '1386575579', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31400', '1386576027', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31412', '1386576091', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31455', '1386080819', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31491', '1386576071', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31541', '1386575545', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31544', '1386575952', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31637', '1386575913', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31681', '1386576090', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31732', '1386575793', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31735', '1386575978', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31939', '1386575915', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31942', '1386575908', '0', '0');
INSERT INTO `creature_respawn` VALUES ('31979', '1386575944', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32025', '1386575873', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32040', '1386575933', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32097', '1386575804', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32139', '1386575949', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32158', '1386576097', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32225', '1386575983', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32248', '1386575966', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32270', '1386575953', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32350', '1386576082', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32388', '1386576058', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32409', '1386082268', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32515', '1386575881', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32634', '1386575929', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32655', '1386576069', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32657', '1386579353', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32771', '1375429453', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32797', '1375429458', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32798', '1376050056', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32809', '1375430038', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32813', '1375427907', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32846', '1374577890', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32865', '1375427716', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32871', '1375429459', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32885', '1375427674', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32910', '1375429442', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32937', '1375429119', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32978', '1374577918', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32994', '1375427892', '0', '0');
INSERT INTO `creature_respawn` VALUES ('32998', '1375427719', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33066', '1375427879', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33099', '1375429078', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33114', '1374577911', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33143', '1375429068', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33154', '1375427877', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33160', '1375427715', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33161', '1375428059', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33239', '1375427867', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33284', '1374762385', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33286', '1374577901', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33314', '1375427750', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33359', '1374577896', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33366', '1375427634', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33386', '1375427920', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33406', '1375427879', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33425', '1375427698', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33467', '1375429443', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33497', '1375429092', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33504', '1375429105', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33520', '1374577916', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33563', '1375429462', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33599', '1375427778', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33656', '1374577884', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33728', '1375427839', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33766', '1374577899', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33777', '1374577895', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33820', '1375427603', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33826', '1376050005', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33861', '1375427905', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33892', '1375429449', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33904', '1375427612', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33911', '1375427851', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33935', '1375427737', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33955', '1375429152', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33973', '1375429070', '0', '0');
INSERT INTO `creature_respawn` VALUES ('33985', '1375427695', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34001', '1375427857', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34023', '1375429454', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34097', '1375429040', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34125', '1375427717', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34142', '1375429441', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34157', '1375427699', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34179', '1375427618', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34286', '1375427627', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34299', '1375427684', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34312', '1375427624', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34320', '1374577913', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34330', '1375427712', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34332', '1374762565', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34333', '1375427891', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34336', '1375429071', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34351', '1375427689', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34381', '1375428002', '0', '0');
INSERT INTO `creature_respawn` VALUES ('34468', '1384709252', '0', '0');
INSERT INTO `creature_respawn` VALUES ('36001', '1380190527', '0', '0');
INSERT INTO `creature_respawn` VALUES ('36026', '1380190491', '0', '0');
INSERT INTO `creature_respawn` VALUES ('36097', '1380190514', '0', '0');
INSERT INTO `creature_respawn` VALUES ('36240', '1380190495', '0', '0');
INSERT INTO `creature_respawn` VALUES ('36245', '1380190543', '0', '0');
INSERT INTO `creature_respawn` VALUES ('36264', '1380190486', '0', '0');
INSERT INTO `creature_respawn` VALUES ('39157', '1385706905', '0', '0');
INSERT INTO `creature_respawn` VALUES ('39474', '1385706895', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40082', '1385567537', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40086', '1385567535', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40359', '1385723595', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40498', '1385659734', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40508', '1385638501', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40512', '1385659730', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40513', '1385485718', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40515', '1385638512', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40529', '1385638503', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40540', '1385485718', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40549', '1385638500', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40551', '1385638503', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40552', '1385638504', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40580', '1385638499', '0', '0');
INSERT INTO `creature_respawn` VALUES ('40581', '1385638506', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41619', '1385638516', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41622', '1385638513', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41624', '1385638540', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41647', '1375429443', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41651', '1376117967', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41653', '1376061424', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41748', '1381329532', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41855', '1383847063', '0', '0');
INSERT INTO `creature_respawn` VALUES ('41943', '1381329545', '0', '0');
INSERT INTO `creature_respawn` VALUES ('42208', '1381329598', '0', '0');
INSERT INTO `creature_respawn` VALUES ('42344', '1381329568', '0', '0');
INSERT INTO `creature_respawn` VALUES ('42408', '1381329493', '0', '0');
INSERT INTO `creature_respawn` VALUES ('42463', '1381329465', '0', '0');
INSERT INTO `creature_respawn` VALUES ('42612', '1381329588', '0', '0');
INSERT INTO `creature_respawn` VALUES ('42747', '1381329485', '0', '0');
INSERT INTO `creature_respawn` VALUES ('42995', '1381329583', '0', '0');
INSERT INTO `creature_respawn` VALUES ('43016', '1381329533', '0', '0');
INSERT INTO `creature_respawn` VALUES ('43019', '1381329488', '0', '0');
INSERT INTO `creature_respawn` VALUES ('43137', '1381329460', '0', '0');
INSERT INTO `creature_respawn` VALUES ('43561', '1375460402', '0', '0');
INSERT INTO `creature_respawn` VALUES ('45742', '1384709250', '0', '0');
INSERT INTO `creature_respawn` VALUES ('45786', '1384710365', '0', '0');
INSERT INTO `creature_respawn` VALUES ('45787', '1384710376', '0', '0');
INSERT INTO `creature_respawn` VALUES ('45860', '1384709026', '0', '0');
INSERT INTO `creature_respawn` VALUES ('45862', '1384709011', '0', '0');
INSERT INTO `creature_respawn` VALUES ('45868', '1384709017', '0', '0');
INSERT INTO `creature_respawn` VALUES ('46244', '1386579250', '0', '0');
INSERT INTO `creature_respawn` VALUES ('46400', '1380187759', '0', '0');
INSERT INTO `creature_respawn` VALUES ('46618', '1376119369', '0', '0');
INSERT INTO `creature_respawn` VALUES ('46620', '1376119103', '0', '0');
INSERT INTO `creature_respawn` VALUES ('46777', '1376119060', '0', '0');
INSERT INTO `creature_respawn` VALUES ('46779', '1376119062', '0', '0');
INSERT INTO `creature_respawn` VALUES ('47617', '1376653856', '0', '0');
INSERT INTO `creature_respawn` VALUES ('47982', '1376653855', '0', '0');
INSERT INTO `creature_respawn` VALUES ('48356', '1374578705', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49605', '1375456720', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49843', '1381329516', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49844', '1381329591', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49910', '1381329533', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49911', '1381329533', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49953', '1381329565', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49959', '1381329512', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49968', '1381329456', '0', '0');
INSERT INTO `creature_respawn` VALUES ('49970', '1381329462', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50000', '1381329519', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50002', '1381329481', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50021', '1381329453', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50025', '1381329531', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50030', '1381329513', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50036', '1381329553', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50050', '1381329534', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50061', '1381329451', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50071', '1381329579', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50073', '1381329566', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50074', '1381329561', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50081', '1381329518', '0', '0');
INSERT INTO `creature_respawn` VALUES ('50088', '1381329555', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51063', '1374579897', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51064', '1374579890', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51065', '1374579878', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51071', '1374579896', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51078', '1374579869', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51081', '1374579860', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51737', '1385638460', '0', '0');
INSERT INTO `creature_respawn` VALUES ('51758', '1385638456', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52512', '1385485977', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52571', '1385485963', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52572', '1385485987', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52573', '1385485982', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52574', '1385485984', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52575', '1385485975', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52576', '1385485987', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52577', '1385485974', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52578', '1385485974', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52588', '1385706894', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52648', '1385485984', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52649', '1385485963', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52650', '1385485969', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52651', '1385485972', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52652', '1385485972', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52653', '1385485961', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52654', '1385485961', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52655', '1385485986', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52656', '1385485959', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52657', '1385485982', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52658', '1385485979', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52732', '1385706898', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52734', '1385706895', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52744', '1385485978', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52758', '1385485978', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52821', '1385486015', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52822', '1385485986', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52824', '1385485973', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52984', '1385485976', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52985', '1385485976', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52986', '1385485972', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52987', '1385485966', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52988', '1385485972', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52989', '1385485970', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52990', '1385485963', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52991', '1385485962', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52992', '1385485968', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52993', '1385485964', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52994', '1385485965', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52995', '1385485962', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52996', '1385485965', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52997', '1385485960', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52998', '1385485964', '0', '0');
INSERT INTO `creature_respawn` VALUES ('52999', '1385485963', '0', '0');
INSERT INTO `creature_respawn` VALUES ('53526', '1386579248', '0', '0');
INSERT INTO `creature_respawn` VALUES ('53607', '1376050822', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54103', '1377796706', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54563', '1386579254', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54564', '1386579254', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54565', '1386579250', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54566', '1386579250', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54567', '1386579250', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54568', '1386579254', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54569', '1386579248', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54573', '1385638544', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54588', '1385659640', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54592', '1385638497', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54600', '1385659770', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54641', '1385638497', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54666', '1385638497', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54699', '1385659661', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54721', '1385638502', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54757', '1385638511', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54788', '1385638451', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54808', '1385638452', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54841', '1385638447', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54843', '1385638464', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54852', '1385638461', '0', '0');
INSERT INTO `creature_respawn` VALUES ('54881', '1385638493', '0', '0');
INSERT INTO `creature_respawn` VALUES ('55560', '1380190180', '0', '0');
INSERT INTO `creature_respawn` VALUES ('55674', '1380190182', '0', '0');
INSERT INTO `creature_respawn` VALUES ('55702', '1380190149', '0', '0');
INSERT INTO `creature_respawn` VALUES ('55749', '1380190150', '0', '0');
INSERT INTO `creature_respawn` VALUES ('55760', '1380190149', '0', '0');
INSERT INTO `creature_respawn` VALUES ('56501', '1375461879', '0', '0');
INSERT INTO `creature_respawn` VALUES ('56547', '1375461678', '0', '0');
INSERT INTO `creature_respawn` VALUES ('56577', '1375461645', '0', '0');
INSERT INTO `creature_respawn` VALUES ('56579', '1375461943', '0', '0');
INSERT INTO `creature_respawn` VALUES ('56623', '1375461958', '0', '0');
INSERT INTO `creature_respawn` VALUES ('56835', '1375458583', '0', '0');
INSERT INTO `creature_respawn` VALUES ('57345', '1375451854', '0', '0');
INSERT INTO `creature_respawn` VALUES ('57375', '1375437839', '0', '0');
INSERT INTO `creature_respawn` VALUES ('57611', '1375462216', '0', '0');
INSERT INTO `creature_respawn` VALUES ('57614', '1375462247', '0', '0');
INSERT INTO `creature_respawn` VALUES ('58685', '1375438173', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59139', '1381214416', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59143', '1381214414', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59145', '1381214412', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59329', '1385567893', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59332', '1385568025', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59333', '1385567897', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59334', '1385567889', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59359', '1385567765', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59360', '1385567765', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59361', '1385567767', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59362', '1385567766', '0', '0');
INSERT INTO `creature_respawn` VALUES ('59431', '1374761522', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60345', '1376052161', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60348', '1376052147', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60427', '1376052161', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60429', '1376052145', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60506', '1376307341', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60518', '1376052151', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60519', '1376052159', '0', '0');
INSERT INTO `creature_respawn` VALUES ('60554', '1376052159', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61109', '1375427535', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61244', '1375427690', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61252', '1375427681', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61254', '1375427646', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61333', '1375427751', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61382', '1375012541', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61384', '1375426100', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61389', '1375427615', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61420', '1375427889', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61439', '1375427821', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61442', '1375427736', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61444', '1375012534', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61445', '1375012531', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61460', '1375012538', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61461', '1375429462', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61465', '1375429461', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61475', '1375427884', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61476', '1375427864', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61481', '1375427912', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61526', '1375428472', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61532', '1375427903', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61533', '1375427887', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61544', '1375429453', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61549', '1375429456', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61568', '1375429460', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61665', '1375429068', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61685', '1375428571', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61686', '1375429036', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61688', '1375429020', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61703', '1375427898', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61715', '1375429450', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61716', '1375429445', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61717', '1375429441', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61718', '1375429436', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61728', '1375429439', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61733', '1375429457', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61772', '1375430658', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61790', '1375430677', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61824', '1374762567', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61828', '1375429446', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61848', '1375429441', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61879', '1375427883', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61881', '1375427898', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61882', '1375429024', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61888', '1375429066', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61889', '1375428460', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61989', '1375429015', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61996', '1375428997', '0', '0');
INSERT INTO `creature_respawn` VALUES ('61998', '1375429048', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62003', '1375429050', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62017', '1375429386', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62028', '1375429443', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62029', '1375429443', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62101', '1375429817', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62102', '1375429818', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62103', '1375429821', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62104', '1375429821', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62105', '1375429804', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62106', '1375429802', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62109', '1375429805', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62110', '1375429819', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62111', '1375429820', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62112', '1375429810', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62142', '1375429440', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62143', '1375429439', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62150', '1375429394', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62151', '1375429064', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62159', '1375429147', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62204', '1375429137', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62205', '1375429128', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62207', '1375429112', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62208', '1375429121', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62226', '1375429074', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62280', '1375429053', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62298', '1375429391', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62300', '1375429389', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62315', '1375429437', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62316', '1375429441', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62317', '1375429444', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62423', '1375429375', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62548', '1374762563', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62553', '1374762564', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62579', '1374762556', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62587', '1375429398', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62588', '1375429398', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62645', '1375429218', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62721', '1374577918', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62722', '1374577913', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62758', '1374762429', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62799', '1374577911', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62800', '1374577901', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62839', '1374577899', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62841', '1374577895', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62848', '1374577893', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62849', '1376050124', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62850', '1374762553', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62888', '1376050527', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62902', '1374577891', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62903', '1374577884', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62905', '1374577870', '0', '0');
INSERT INTO `creature_respawn` VALUES ('62906', '1374577869', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63033', '1376050644', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63446', '1386575456', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63448', '1386575292', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63474', '1386575913', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63475', '1386575916', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63486', '1385638449', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63953', '1386575445', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63984', '1386575460', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63993', '1386575918', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63997', '1386575911', '0', '0');
INSERT INTO `creature_respawn` VALUES ('63998', '1386575900', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64000', '1386575810', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64002', '1386575883', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64003', '1386575800', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64004', '1386575886', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64005', '1386575794', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64006', '1386575876', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64017', '1386575888', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64018', '1386575890', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64019', '1386575879', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64020', '1386575872', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64021', '1386575930', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64022', '1386575932', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64026', '1386575929', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64028', '1386575347', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64089', '1386575976', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64114', '1386575979', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64156', '1386575391', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64159', '1386575621', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64163', '1386575948', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64164', '1386575959', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64165', '1386575949', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64166', '1386575964', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64167', '1386576238', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64168', '1386575986', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64184', '1386575954', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64185', '1386575944', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64186', '1386575951', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64212', '1386575580', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64213', '1386575578', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64225', '1386575998', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64259', '1374398726', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64260', '1374398724', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64261', '1374398726', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64266', '1386575509', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64366', '1374398722', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64393', '1386576030', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64467', '1386576066', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64468', '1386576068', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64470', '1386576075', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64471', '1386576083', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64472', '1386576074', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64473', '1386576080', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64488', '1386080820', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64500', '1385902256', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64526', '1386576087', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64579', '1386576093', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64767', '1386925031', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64956', '1386082268', '0', '0');
INSERT INTO `creature_respawn` VALUES ('64976', '1386953833', '0', '0');
INSERT INTO `creature_respawn` VALUES ('65042', '1386925287', '0', '0');
INSERT INTO `creature_respawn` VALUES ('65048', '1378648765', '0', '0');
INSERT INTO `creature_respawn` VALUES ('65178', '1386082428', '0', '0');
INSERT INTO `creature_respawn` VALUES ('65250', '1386924035', '0', '0');
INSERT INTO `creature_respawn` VALUES ('65307', '1386082428', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66362', '1375450995', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66430', '1375451038', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66558', '1385628688', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66561', '1385628670', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66565', '1385628673', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66637', '1375432110', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66743', '1375433363', '0', '0');
INSERT INTO `creature_respawn` VALUES ('66796', '1384708823', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67039', '1375451616', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67096', '1375451628', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67097', '1375450028', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67127', '1375451688', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67141', '1375431474', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67164', '1375451683', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67260', '1376305374', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67280', '1376305378', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67284', '1376305375', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67285', '1376305376', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67395', '1384501720', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67413', '1380190540', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67429', '1380190546', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67433', '1380190548', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67468', '1380190498', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67542', '1380190533', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67544', '1380190519', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67569', '1380190551', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67572', '1380190486', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67616', '1380190496', '0', '0');
INSERT INTO `creature_respawn` VALUES ('67654', '1380190518', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71027', '1383847062', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71029', '1383847102', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71036', '1383847062', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71462', '1376118993', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71499', '1375430640', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71568', '1375451626', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71570', '1380735932', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71596', '1375430668', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71610', '1376305373', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71620', '1376305375', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71621', '1376305376', '0', '0');
INSERT INTO `creature_respawn` VALUES ('71629', '1374578675', '0', '0');
INSERT INTO `creature_respawn` VALUES ('72406', '1386496644', '1', '0');
INSERT INTO `creature_respawn` VALUES ('72654', '1375881419', '1', '0');
INSERT INTO `creature_respawn` VALUES ('72660', '1375881469', '1', '0');
INSERT INTO `creature_respawn` VALUES ('72668', '1375881364', '1', '0');
INSERT INTO `creature_respawn` VALUES ('72681', '1375881473', '1', '0');
INSERT INTO `creature_respawn` VALUES ('72790', '1375881488', '1', '0');
INSERT INTO `creature_respawn` VALUES ('77462', '1384717279', '1', '0');
INSERT INTO `creature_respawn` VALUES ('77490', '1384755958', '1', '0');
INSERT INTO `creature_respawn` VALUES ('77595', '1384755971', '1', '0');
INSERT INTO `creature_respawn` VALUES ('77798', '1384755918', '1', '0');
INSERT INTO `creature_respawn` VALUES ('77837', '1384755967', '1', '0');
INSERT INTO `creature_respawn` VALUES ('77944', '1384717275', '1', '0');
INSERT INTO `creature_respawn` VALUES ('77963', '1384717267', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78004', '1384714648', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78127', '1384717283', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78153', '1384714657', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78216', '1384714649', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78219', '1384755954', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78391', '1384714650', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78447', '1384759674', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78476', '1384755963', '1', '0');
INSERT INTO `creature_respawn` VALUES ('78619', '1386059397', '1', '0');
INSERT INTO `creature_respawn` VALUES ('80090', '1375881385', '1', '0');
INSERT INTO `creature_respawn` VALUES ('81028', '1379339809', '1', '0');
INSERT INTO `creature_respawn` VALUES ('81033', '1379339801', '1', '0');
INSERT INTO `creature_respawn` VALUES ('81044', '1379339779', '1', '0');
INSERT INTO `creature_respawn` VALUES ('88409', '1384717144', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89388', '1386059303', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89520', '1386059300', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89572', '1386059304', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89597', '1386059297', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89749', '1386059255', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89753', '1386059330', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89756', '1386059336', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89759', '1386059292', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89795', '1386059335', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89826', '1386059332', '1', '0');
INSERT INTO `creature_respawn` VALUES ('89916', '1386059300', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90050', '1386059333', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90103', '1386059333', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90242', '1386059225', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90369', '1384714648', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90467', '1384717264', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90469', '1387019681', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90529', '1384717304', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90552', '1384717287', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90669', '1386923206', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90683', '1386923090', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90698', '1375624582', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90701', '1386923601', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90722', '1375624445', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90733', '1386923151', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90738', '1386923198', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90769', '1386922878', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90776', '1384756450', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90777', '1386923129', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90797', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90818', '1386923124', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90819', '1386923218', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90916', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90917', '1386922874', '1', '0');
INSERT INTO `creature_respawn` VALUES ('90946', '1386923229', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91019', '1386923071', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91023', '1386923219', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91025', '1384756344', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91031', '1386923151', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91038', '1386923115', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91070', '1386923105', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91073', '1375624557', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91083', '1386923013', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91085', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91140', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91176', '1384756580', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91203', '1386923804', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91204', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91240', '1386923190', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91304', '1386923235', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91324', '1386923758', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91326', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91331', '1386923250', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91334', '1386923069', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91363', '1386923238', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91367', '1386923276', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91393', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91434', '1386922878', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91443', '1386923251', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91476', '1386923030', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91488', '1386923570', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91515', '1386923114', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91518', '1386923038', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91522', '1381329106', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91535', '1375624572', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91549', '1375624568', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91550', '1386923014', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91554', '1386922871', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91658', '1386923045', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91703', '1386923082', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91710', '1386922872', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91723', '1386923225', '1', '0');
INSERT INTO `creature_respawn` VALUES ('91741', '1375876185', '1', '0');
INSERT INTO `creature_respawn` VALUES ('94620', '1386426398', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96754', '1386923107', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96772', '1386923016', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96789', '1386923253', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96802', '1386923211', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96808', '1386923014', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96838', '1386923703', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96923', '1386923209', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96930', '1386922875', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96945', '1386923213', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96952', '1375624562', '1', '0');
INSERT INTO `creature_respawn` VALUES ('96985', '1375772901', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97011', '1376494440', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97072', '1386923088', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97080', '1384717300', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97106', '1386923016', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97115', '1386923060', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97139', '1386923092', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97166', '1375624576', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97177', '1384714658', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97230', '1386923123', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97235', '1386927355', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97250', '1386923025', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97274', '1386923120', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97310', '1386923064', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97324', '1386923025', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97335', '1386923534', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97336', '1386923233', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97338', '1386923086', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97342', '1375624560', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97367', '1386923042', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97382', '1386923036', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97386', '1386923012', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97394', '1386923062', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97401', '1386923012', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97466', '1386923058', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97482', '1386923039', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97514', '1386923248', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97519', '1386923261', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97529', '1384755991', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97536', '1386923514', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97543', '1376494520', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97560', '1386923034', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97580', '1386923111', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97584', '1386923073', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97596', '1386923246', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97607', '1386923660', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97615', '1386923013', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97630', '1386923194', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97660', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97674', '1386923035', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97681', '1386923033', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97702', '1386923705', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97705', '1386923056', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97712', '1386923070', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97804', '1386922876', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97816', '1386923125', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97830', '1386923260', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97850', '1386923241', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97859', '1386923066', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97885', '1386923767', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97908', '1386922880', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97977', '1379339805', '1', '0');
INSERT INTO `creature_respawn` VALUES ('97998', '1375624438', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98040', '1375624575', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98046', '1386927327', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98101', '1386923040', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98126', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98218', '1386923196', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98225', '1386923078', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98245', '1386923054', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98330', '1386923592', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98357', '1386923031', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98372', '1386923032', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98379', '1375624559', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98380', '1386923096', '1', '0');
INSERT INTO `creature_respawn` VALUES ('98403', '1386923093', '1', '0');
INSERT INTO `creature_respawn` VALUES ('100349', '1378291010', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101083', '1375879771', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101155', '1375618613', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101159', '1375879837', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101163', '1375880244', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101202', '1375618614', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101208', '1375618634', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101214', '1375880723', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101266', '1384717303', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101372', '1375880044', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101381', '1384755951', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101427', '1375618612', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101498', '1375618634', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101515', '1375880811', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101578', '1375881874', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101637', '1375618615', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101817', '1375618621', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101823', '1375618633', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101930', '1375618611', '1', '0');
INSERT INTO `creature_respawn` VALUES ('101958', '1375618338', '1', '0');
INSERT INTO `creature_respawn` VALUES ('102126', '1375880342', '1', '0');
INSERT INTO `creature_respawn` VALUES ('102142', '1375879853', '1', '0');
INSERT INTO `creature_respawn` VALUES ('102148', '1375880790', '1', '0');
INSERT INTO `creature_respawn` VALUES ('102153', '1375618617', '1', '0');
INSERT INTO `creature_respawn` VALUES ('102956', '1375881489', '1', '0');
INSERT INTO `creature_respawn` VALUES ('103161', '1375881472', '1', '0');
INSERT INTO `creature_respawn` VALUES ('103699', '1375881350', '1', '0');
INSERT INTO `creature_respawn` VALUES ('104088', '1375881467', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106356', '1386059288', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106455', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106494', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106499', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106512', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106515', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106545', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106548', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106560', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106568', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106590', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106615', '1384717286', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106633', '1386496971', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106647', '1375622979', '1', '0');
INSERT INTO `creature_respawn` VALUES ('106659', '1375623323', '1', '0');
INSERT INTO `creature_respawn` VALUES ('107383', '1384717131', '1', '0');
INSERT INTO `creature_respawn` VALUES ('107392', '1374234117', '1', '0');
INSERT INTO `creature_respawn` VALUES ('107405', '1386496976', '1', '0');
INSERT INTO `creature_respawn` VALUES ('107561', '1375878369', '1', '0');
INSERT INTO `creature_respawn` VALUES ('107916', '1375878366', '1', '0');
INSERT INTO `creature_respawn` VALUES ('108020', '1386496982', '1', '0');
INSERT INTO `creature_respawn` VALUES ('108259', '1374234115', '1', '0');
INSERT INTO `creature_respawn` VALUES ('108462', '1386426655', '1', '0');
INSERT INTO `creature_respawn` VALUES ('108472', '1376059779', '1', '0');
INSERT INTO `creature_respawn` VALUES ('108670', '1386423741', '1', '0');
INSERT INTO `creature_respawn` VALUES ('108781', '1386426536', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109482', '1375788714', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109592', '1384717294', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109798', '1386059961', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109802', '1386059991', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109803', '1386059972', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109806', '1386059966', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109808', '1386059983', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109809', '1386059928', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109810', '1386059983', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109811', '1386059978', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109812', '1386059947', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109814', '1386059949', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109816', '1386059894', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109818', '1386059950', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109819', '1386059958', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109820', '1386059990', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109824', '1386059991', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109826', '1386059978', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109827', '1386059882', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109828', '1386059958', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109830', '1386059998', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109832', '1386059990', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109833', '1386059978', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109834', '1386059999', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109836', '1386059991', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109840', '1386059882', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109841', '1386059997', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109844', '1386059983', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109846', '1386059963', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109847', '1386059931', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109848', '1386059974', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109850', '1386059993', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109852', '1386059881', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109853', '1386059995', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109858', '1386059972', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109863', '1386059961', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109864', '1386059973', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109865', '1386059813', '1', '0');
INSERT INTO `creature_respawn` VALUES ('109870', '1386059992', '1', '0');
INSERT INTO `creature_respawn` VALUES ('110482', '1386423747', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119252', '1375519985', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119464', '1376560082', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119465', '1376560075', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119468', '1376559985', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119471', '1376560073', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119472', '1376560117', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119506', '1376560088', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119507', '1376559980', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119508', '1376559956', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119509', '1376559978', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119510', '1376560064', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119511', '1376560058', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119512', '1376560044', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119513', '1376560077', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119514', '1376560070', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119515', '1376560030', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119516', '1376560042', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119517', '1376652504', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119518', '1376560126', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119519', '1376560116', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119520', '1376560133', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119521', '1376560084', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119522', '1376560106', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119523', '1376652486', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119525', '1376560042', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119526', '1376560105', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119528', '1376560105', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119530', '1376560141', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119836', '1376560589', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119837', '1376560661', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119840', '1376560561', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119841', '1376560693', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119842', '1376560603', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119844', '1376560560', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119977', '1383213878', '1', '0');
INSERT INTO `creature_respawn` VALUES ('119982', '1383213876', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120102', '1376560571', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120214', '1376559636', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120215', '1376559568', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120216', '1376559574', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120217', '1376559563', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120218', '1376559548', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120219', '1376559545', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120220', '1376559535', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120221', '1376559520', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120222', '1376559523', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120227', '1376559597', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120230', '1376559575', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120231', '1376559528', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120232', '1376559533', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120233', '1376559535', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120418', '1378134450', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120702', '1387021478', '1', '0');
INSERT INTO `creature_respawn` VALUES ('120966', '1386423685', '1', '0');
INSERT INTO `creature_respawn` VALUES ('121702', '1384717261', '1', '0');
INSERT INTO `creature_respawn` VALUES ('122464', '1384756636', '1', '0');
INSERT INTO `creature_respawn` VALUES ('122478', '1384756500', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123384', '1386059280', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123385', '1386059222', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123387', '1386059229', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123392', '1386059323', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123400', '1386059290', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123435', '1386059326', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123436', '1386059329', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123477', '1386059258', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123483', '1386059285', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123486', '1386059291', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123496', '1386059251', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123508', '1386059333', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123517', '1386059286', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123548', '1386059303', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123732', '1380190399', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123864', '1386923257', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123992', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123995', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123996', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123997', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('123998', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124002', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124003', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124004', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124005', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124006', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124007', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124008', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124009', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124010', '1379339689', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124241', '1386923226', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124487', '1376657517', '1', '0');
INSERT INTO `creature_respawn` VALUES ('124577', '1375878369', '1', '0');
INSERT INTO `creature_respawn` VALUES ('125384', '1375882271', '1', '0');
INSERT INTO `creature_respawn` VALUES ('126162', '1374234119', '1', '0');
INSERT INTO `creature_respawn` VALUES ('126631', '1386923570', '1', '0');
INSERT INTO `creature_respawn` VALUES ('126638', '1386923623', '1', '0');
INSERT INTO `creature_respawn` VALUES ('126642', '1386923609', '1', '0');
INSERT INTO `creature_respawn` VALUES ('126652', '1387017256', '1', '0');
INSERT INTO `creature_respawn` VALUES ('126653', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('126654', '1387017887', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127002', '1386923243', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127005', '1386923244', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127006', '1386923248', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127008', '1386923237', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127010', '1386923221', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127013', '1386923221', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127016', '1386923208', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127017', '1386923212', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127018', '1386923207', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127020', '1386923203', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127030', '1375624440', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127039', '1386923198', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127040', '1386923194', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127042', '1386923195', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127043', '1386923190', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127078', '1386923029', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127081', '1386923043', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127083', '1386923046', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127089', '1386923047', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127116', '1386923060', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127118', '1386923059', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127119', '1386923080', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127126', '1386923063', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127132', '1386923112', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127135', '1386923123', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127137', '1386923117', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127138', '1386923114', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127139', '1386923075', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127140', '1386923127', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127141', '1386923109', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127143', '1386923097', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127144', '1386923119', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127146', '1386923085', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127147', '1386923077', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127149', '1386923073', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127151', '1386923074', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127157', '1386923091', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127159', '1386923092', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127160', '1386923088', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127167', '1386923094', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127170', '1386923083', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127206', '1386923012', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127210', '1386923015', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127212', '1386923024', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127213', '1386923013', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127317', '1386922873', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127323', '1386922873', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127326', '1386922877', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127327', '1386922890', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127484', '1379337104', '1', '0');
INSERT INTO `creature_respawn` VALUES ('127862', '1384756270', '1', '0');
INSERT INTO `creature_respawn` VALUES ('128448', '1384756165', '1', '0');
INSERT INTO `creature_respawn` VALUES ('128474', '1384756298', '1', '0');
INSERT INTO `creature_respawn` VALUES ('128502', '1384715885', '1', '0');
INSERT INTO `creature_respawn` VALUES ('128537', '1384756434', '1', '0');
INSERT INTO `creature_respawn` VALUES ('129309', '1387019667', '1', '0');
INSERT INTO `creature_respawn` VALUES ('138230', '1375618609', '1', '0');
INSERT INTO `creature_respawn` VALUES ('138250', '1375618569', '1', '0');
INSERT INTO `creature_respawn` VALUES ('138252', '1375618570', '1', '0');
INSERT INTO `creature_respawn` VALUES ('138255', '1375618571', '1', '0');
INSERT INTO `creature_respawn` VALUES ('138598', '1375880326', '1', '0');
INSERT INTO `creature_respawn` VALUES ('138601', '1375880791', '1', '0');
INSERT INTO `creature_respawn` VALUES ('138615', '1375880815', '1', '0');
INSERT INTO `creature_respawn` VALUES ('139071', '1375622977', '1', '0');
INSERT INTO `creature_respawn` VALUES ('139082', '1375622918', '1', '0');
INSERT INTO `creature_respawn` VALUES ('139083', '1375622916', '1', '0');
INSERT INTO `creature_respawn` VALUES ('139135', '1375623323', '1', '0');
INSERT INTO `creature_respawn` VALUES ('139174', '1386496990', '1', '0');
INSERT INTO `creature_respawn` VALUES ('139178', '1386496986', '1', '0');
INSERT INTO `creature_respawn` VALUES ('139189', '1386496978', '1', '0');
INSERT INTO `creature_respawn` VALUES ('146143', '1376059779', '1', '0');
INSERT INTO `creature_respawn` VALUES ('146408', '1386423693', '1', '0');
INSERT INTO `creature_respawn` VALUES ('146470', '1386423718', '1', '0');
INSERT INTO `creature_respawn` VALUES ('162263', '1385622700', '530', '0');
INSERT INTO `creature_respawn` VALUES ('162265', '1385622702', '530', '0');
INSERT INTO `creature_respawn` VALUES ('174803', '1381247298', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179237', '1383247307', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179238', '1383247305', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179331', '1376462287', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179334', '1376462284', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179338', '1376462289', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179475', '1376312622', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179494', '1383247306', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179501', '1383247305', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179514', '1383247308', '530', '0');
INSERT INTO `creature_respawn` VALUES ('179531', '1383247303', '530', '0');
INSERT INTO `creature_respawn` VALUES ('185232', '1385572347', '530', '0');
INSERT INTO `creature_respawn` VALUES ('195978', '1384450518', '571', '0');
INSERT INTO `creature_respawn` VALUES ('195981', '1381214807', '571', '0');
INSERT INTO `creature_respawn` VALUES ('218070', '1375542910', '571', '0');
INSERT INTO `creature_respawn` VALUES ('222249', '1375542916', '571', '0');
INSERT INTO `creature_respawn` VALUES ('223282', '1381214666', '571', '0');
INSERT INTO `creature_respawn` VALUES ('223301', '1381214646', '571', '0');
INSERT INTO `creature_respawn` VALUES ('223733', '1375542913', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225666', '1386925464', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225667', '1386925465', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225669', '1386925414', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225674', '1386925573', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225813', '1386925548', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225821', '1386925685', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225895', '1386925593', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225900', '1386925659', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225904', '1386925598', '571', '0');
INSERT INTO `creature_respawn` VALUES ('225913', '1386925648', '571', '0');
INSERT INTO `creature_respawn` VALUES ('232305', '1381211564', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232306', '1381211569', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232308', '1381211665', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232317', '1381211578', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232352', '1381211604', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232372', '1381211574', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232373', '1381211567', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232377', '1381211603', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232592', '1381211571', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232593', '1381211561', '609', '0');
INSERT INTO `creature_respawn` VALUES ('232610', '1381211562', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233049', '1385462050', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233050', '1385462147', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233090', '1385462115', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233095', '1385462228', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233100', '1385462115', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233116', '1385461619', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233117', '1385461617', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233123', '1385461609', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233124', '1385462226', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233129', '1385461611', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233155', '1385462269', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233156', '1385462231', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233167', '1385462177', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233177', '1385462005', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233184', '1385462050', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233222', '1385462050', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233226', '1385461943', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233227', '1385461871', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233228', '1385462224', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233229', '1385462265', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233230', '1385461611', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233231', '1385462263', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233249', '1385461771', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233260', '1385461615', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233261', '1385462230', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233262', '1385461613', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233263', '1385462269', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233264', '1385462228', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233319', '1385461739', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233320', '1385461678', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233336', '1385462131', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233364', '1385461605', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233373', '1385461540', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233425', '1385461227', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233426', '1385461327', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233427', '1385461304', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233628', '1385461723', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233629', '1385461698', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233631', '1385461684', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233632', '1385461686', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233704', '1385461611', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233716', '1385461599', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233722', '1385461509', '609', '0');
INSERT INTO `creature_respawn` VALUES ('233734', '1385462175', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234226', '1381210799', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234228', '1381210799', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234252', '1381210799', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234255', '1381210799', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234291', '1381210799', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234552', '1385461319', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234587', '1385461588', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234588', '1385461594', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234589', '1385461704', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234595', '1385461667', '609', '0');
INSERT INTO `creature_respawn` VALUES ('234599', '1385461610', '609', '0');
INSERT INTO `creature_respawn` VALUES ('236013', '1381419970', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236050', '1386081842', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236074', '1386081845', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236350', '1386081937', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236351', '1386081932', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236425', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236426', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236450', '1381419883', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236464', '1381419864', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236483', '1381419851', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236496', '1381419847', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236499', '1381419855', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236500', '1381419863', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236502', '1381419872', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236503', '1381419861', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236506', '1381419844', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236507', '1381419826', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236509', '1381419855', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236512', '1381419850', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236513', '1381419849', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236515', '1381419849', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236519', '1381419849', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236521', '1381419851', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236523', '1381419856', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236525', '1381419860', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236538', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236539', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236545', '1381419857', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236549', '1381419854', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236553', '1381419868', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236554', '1381419856', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236555', '1381419868', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236556', '1381419852', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236557', '1381419852', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236560', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236561', '1381419858', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236576', '1381419960', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236577', '1381419928', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236588', '1381419920', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236591', '1381419868', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236593', '1381419858', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236595', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236600', '1381419858', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236602', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236613', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236615', '1381419864', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236627', '1381419867', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236628', '1381419883', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236638', '1381419860', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236642', '1381419856', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236651', '1381419862', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236671', '1381419866', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236672', '1381419866', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236675', '1381419866', '638', '0');
INSERT INTO `creature_respawn` VALUES ('236802', '1386081842', '638', '0');
INSERT INTO `creature_respawn` VALUES ('238186', '1386356120', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238229', '1386321954', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238233', '1386321980', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238242', '1386322904', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238243', '1386322877', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238244', '1386322869', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238245', '1386322871', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238259', '1386321968', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238260', '1386321954', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238280', '1386322868', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238294', '1386321965', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238295', '1386321962', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238296', '1386321966', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238309', '1386322903', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238310', '1386322867', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238320', '1386322874', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238321', '1386322879', '646', '0');
INSERT INTO `creature_respawn` VALUES ('238322', '1386322870', '646', '0');
INSERT INTO `creature_respawn` VALUES ('239461', '1386322039', '646', '0');
INSERT INTO `creature_respawn` VALUES ('239462', '1386322901', '646', '0');
INSERT INTO `creature_respawn` VALUES ('239593', '1383832661', '648', '0');
INSERT INTO `creature_respawn` VALUES ('239677', '1383832651', '648', '0');
INSERT INTO `creature_respawn` VALUES ('240555', '1383655480', '648', '0');
INSERT INTO `creature_respawn` VALUES ('241976', '1383651668', '648', '0');
INSERT INTO `creature_respawn` VALUES ('241977', '1383651663', '648', '0');
INSERT INTO `creature_respawn` VALUES ('241981', '1383651643', '648', '0');
INSERT INTO `creature_respawn` VALUES ('241982', '1383651657', '648', '0');
INSERT INTO `creature_respawn` VALUES ('242393', '1385712150', '648', '0');
INSERT INTO `creature_respawn` VALUES ('242618', '1383655323', '648', '0');
INSERT INTO `creature_respawn` VALUES ('242619', '1383655323', '648', '0');
INSERT INTO `creature_respawn` VALUES ('243090', '1383651749', '648', '0');
INSERT INTO `creature_respawn` VALUES ('243092', '1383651768', '648', '0');
INSERT INTO `creature_respawn` VALUES ('243110', '1383651755', '648', '0');
INSERT INTO `creature_respawn` VALUES ('243115', '1383651752', '648', '0');
INSERT INTO `creature_respawn` VALUES ('243126', '1383651754', '648', '0');
INSERT INTO `creature_respawn` VALUES ('243139', '1383651770', '648', '0');
INSERT INTO `creature_respawn` VALUES ('244616', '1383832645', '648', '0');
INSERT INTO `creature_respawn` VALUES ('245235', '1381424300', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246931', '1381425073', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246932', '1381425088', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246935', '1381425094', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246937', '1381425176', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246944', '1381425199', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246948', '1381425086', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246986', '1381424653', '654', '0');
INSERT INTO `creature_respawn` VALUES ('246991', '1381424544', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247013', '1381424525', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247067', '1381424281', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247077', '1381424338', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247078', '1381424302', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247079', '1381424304', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247080', '1381424343', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247082', '1381424340', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247083', '1381424245', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247085', '1381424247', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247087', '1381424332', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247100', '1381424612', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247108', '1381424618', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247115', '1381424608', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247140', '1381424882', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247141', '1381424880', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247145', '1381424851', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247146', '1381424802', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247150', '1381424774', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247154', '1381424869', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247155', '1381424907', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247402', '1381422604', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247403', '1381422635', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247406', '1381422572', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247407', '1381422624', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247408', '1381422579', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247409', '1381422594', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247411', '1381422552', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247413', '1381422632', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247415', '1381422656', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247417', '1381422591', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247419', '1381422602', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247564', '1381423196', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247566', '1381423203', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247571', '1381423216', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247572', '1381423211', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247573', '1381423232', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247574', '1381423181', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247575', '1381423214', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247578', '1381423229', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247628', '1378395484', '655', '0');
INSERT INTO `creature_respawn` VALUES ('247646', '1381423967', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247673', '1384069535', '654', '0');
INSERT INTO `creature_respawn` VALUES ('247910', '1378401245', '655', '0');
INSERT INTO `creature_respawn` VALUES ('247932', '1378401233', '655', '0');
INSERT INTO `creature_respawn` VALUES ('247945', '1378401231', '655', '0');
INSERT INTO `creature_respawn` VALUES ('247952', '1378401229', '655', '0');
INSERT INTO `creature_respawn` VALUES ('247953', '1384069473', '654', '0');
INSERT INTO `creature_respawn` VALUES ('250339', '1386149172', '732', '0');
INSERT INTO `creature_respawn` VALUES ('251295', '1386149175', '732', '0');
INSERT INTO `creature_respawn` VALUES ('300693', '1386081936', '638', '0');
INSERT INTO `creature_respawn` VALUES ('300715', '1381432064', '654', '0');
INSERT INTO `creature_respawn` VALUES ('301077', '1375601340', '1', '0');
INSERT INTO `creature_respawn` VALUES ('321300', '1383212772', '1', '0');
INSERT INTO `creature_respawn` VALUES ('321304', '1383220093', '1', '0');
INSERT INTO `creature_respawn` VALUES ('321305', '1383220143', '1', '0');
INSERT INTO `creature_respawn` VALUES ('321309', '1383220136', '1', '0');
INSERT INTO `creature_respawn` VALUES ('321312', '1383239821', '1', '0');
INSERT INTO `creature_respawn` VALUES ('406051', '1386576233', '0', '0');
INSERT INTO `creature_respawn` VALUES ('407323', '1386323337', '646', '0');
INSERT INTO `creature_respawn` VALUES ('407803', '1386922363', '1', '0');
INSERT INTO `creature_respawn` VALUES ('7239109', '1381420146', '638', '0');
INSERT INTO `creature_respawn` VALUES ('7239112', '1381420180', '638', '0');
INSERT INTO `creature_respawn` VALUES ('7239113', '1381420177', '638', '0');
INSERT INTO `creature_respawn` VALUES ('7239114', '1381420162', '638', '0');
INSERT INTO `creature_respawn` VALUES ('7239117', '1381420156', '638', '0');
INSERT INTO `creature_respawn` VALUES ('7350247', '1374336387', '0', '0');
INSERT INTO `creature_respawn` VALUES ('7352693', '1376051114', '0', '0');
INSERT INTO `creature_respawn` VALUES ('7352694', '1376051958', '1', '0');
INSERT INTO `creature_respawn` VALUES ('7352696', '1376052199', '646', '0');
INSERT INTO `creature_respawn` VALUES ('7358862', '1381420209', '638', '0');

-- ----------------------------
-- Table structure for gameobject_respawn
-- ----------------------------
DROP TABLE IF EXISTS `gameobject_respawn`;
CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` int(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';

-- ----------------------------
-- Records of gameobject_respawn
-- ----------------------------
INSERT INTO `gameobject_respawn` VALUES ('9106', '1384670462', '0', '0');
INSERT INTO `gameobject_respawn` VALUES ('9108', '1384670466', '0', '0');
INSERT INTO `gameobject_respawn` VALUES ('13146', '1386923103', '0', '1');
INSERT INTO `gameobject_respawn` VALUES ('56020', '1385461125', '0', '609');
INSERT INTO `gameobject_respawn` VALUES ('56430', '1381210638', '0', '609');
INSERT INTO `gameobject_respawn` VALUES ('58542', '1381425078', '0', '654');
INSERT INTO `gameobject_respawn` VALUES ('58543', '1381425065', '0', '654');
INSERT INTO `gameobject_respawn` VALUES ('58545', '1381425070', '0', '654');
INSERT INTO `gameobject_respawn` VALUES ('58551', '1381425061', '0', '654');
INSERT INTO `gameobject_respawn` VALUES ('58556', '1381425050', '0', '654');
INSERT INTO `gameobject_respawn` VALUES ('2000174', '1381423283', '0', '654');
INSERT INTO `gameobject_respawn` VALUES ('4004906', '1383650715', '0', '648');
INSERT INTO `gameobject_respawn` VALUES ('4005419', '1384762806', '0', '1');
INSERT INTO `gameobject_respawn` VALUES ('4005422', '1384776857', '0', '1');
INSERT INTO `gameobject_respawn` VALUES ('4005428', '1384776875', '0', '1');
INSERT INTO `gameobject_respawn` VALUES ('4005430', '1384776851', '0', '1');

-- ----------------------------
-- Table structure for game_event_condition_save
-- ----------------------------
DROP TABLE IF EXISTS `game_event_condition_save`;
CREATE TABLE `game_event_condition_save` (
  `condition_id` int(10) unsigned NOT NULL DEFAULT '0',
  `done` float DEFAULT '0',
  `eventEntry` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventEntry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of game_event_condition_save
-- ----------------------------

-- ----------------------------
-- Table structure for game_event_save
-- ----------------------------
DROP TABLE IF EXISTS `game_event_save`;
CREATE TABLE `game_event_save` (
  `eventEntry` tinyint(3) unsigned NOT NULL,
  `state` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `next_start` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventEntry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of game_event_save
-- ----------------------------
INSERT INTO `game_event_save` VALUES ('33', '2', '0');
INSERT INTO `game_event_save` VALUES ('34', '2', '0');
INSERT INTO `game_event_save` VALUES ('35', '2', '0');
INSERT INTO `game_event_save` VALUES ('36', '2', '0');
INSERT INTO `game_event_save` VALUES ('37', '2', '0');
INSERT INTO `game_event_save` VALUES ('38', '2', '0');
INSERT INTO `game_event_save` VALUES ('39', '2', '0');
INSERT INTO `game_event_save` VALUES ('40', '2', '0');
INSERT INTO `game_event_save` VALUES ('41', '2', '0');
INSERT INTO `game_event_save` VALUES ('43', '2', '0');
INSERT INTO `game_event_save` VALUES ('44', '2', '0');
INSERT INTO `game_event_save` VALUES ('45', '2', '0');
INSERT INTO `game_event_save` VALUES ('46', '2', '0');
INSERT INTO `game_event_save` VALUES ('47', '2', '0');

-- ----------------------------
-- Table structure for gm_subsurveys
-- ----------------------------
DROP TABLE IF EXISTS `gm_subsurveys`;
CREATE TABLE `gm_subsurveys` (
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subsurveyId` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  PRIMARY KEY (`surveyId`,`subsurveyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of gm_subsurveys
-- ----------------------------

-- ----------------------------
-- Table structure for gm_surveys
-- ----------------------------
DROP TABLE IF EXISTS `gm_surveys`;
CREATE TABLE `gm_surveys` (
  `guid` int(10) NOT NULL,
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mainSurvey` int(10) unsigned NOT NULL DEFAULT '0',
  `overallComment` longtext NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`surveyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of gm_surveys
-- ----------------------------

-- ----------------------------
-- Table structure for gm_tickets
-- ----------------------------
DROP TABLE IF EXISTS `gm_tickets`;
CREATE TABLE `gm_tickets` (
  `ticketId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier of ticket creator',
  `name` varchar(12) NOT NULL COMMENT 'Name of ticket creator',
  `message` text NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `lastModifiedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `closedBy` int(10) NOT NULL DEFAULT '0',
  `assignedTo` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'GUID of admin to whom ticket is assigned',
  `comment` text NOT NULL,
  `response` text NOT NULL,
  `completed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `escalated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `viewed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `haveTicket` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ticketId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of gm_tickets
-- ----------------------------

-- ----------------------------
-- Table structure for groups
-- ----------------------------
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `guid` int(10) unsigned NOT NULL,
  `leaderGuid` int(10) unsigned NOT NULL,
  `lootMethod` tinyint(3) unsigned NOT NULL,
  `looterGuid` int(10) unsigned NOT NULL,
  `lootThreshold` tinyint(3) unsigned NOT NULL,
  `icon1` int(10) unsigned NOT NULL,
  `icon2` int(10) unsigned NOT NULL,
  `icon3` int(10) unsigned NOT NULL,
  `icon4` int(10) unsigned NOT NULL,
  `icon5` int(10) unsigned NOT NULL,
  `icon6` int(10) unsigned NOT NULL,
  `icon7` int(10) unsigned NOT NULL,
  `icon8` int(10) unsigned NOT NULL,
  `groupType` tinyint(3) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `raiddifficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`),
  KEY `leaderGuid` (`leaderGuid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';

-- ----------------------------
-- Records of groups
-- ----------------------------

-- ----------------------------
-- Table structure for group_instance
-- ----------------------------
DROP TABLE IF EXISTS `group_instance`;
CREATE TABLE `group_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of group_instance
-- ----------------------------

-- ----------------------------
-- Table structure for group_member
-- ----------------------------
DROP TABLE IF EXISTS `group_member`;
CREATE TABLE `group_member` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `memberGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `memberFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `subgroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `roles` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`memberGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';

-- ----------------------------
-- Records of group_member
-- ----------------------------

-- ----------------------------
-- Table structure for guild
-- ----------------------------
DROP TABLE IF EXISTS `guild`;
CREATE TABLE `guild` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `leaderguid` int(10) unsigned NOT NULL DEFAULT '0',
  `EmblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `EmblemColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BackgroundColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `info` text NOT NULL,
  `motd` varchar(128) NOT NULL DEFAULT '',
  `createdate` int(10) unsigned NOT NULL DEFAULT '0',
  `BankMoney` bigint(20) unsigned NOT NULL DEFAULT '0',
  `level` int(10) unsigned DEFAULT '1',
  `todayExperience` bigint(20) unsigned DEFAULT '0',
  `RaidChallenge` int(10) NOT NULL DEFAULT '0',
  `ChallengeCount` int(32) unsigned NOT NULL DEFAULT '0',
  `RatedBGChallenge` int(10) NOT NULL DEFAULT '0',
  `DungeonChallenge` int(10) NOT NULL DEFAULT '0',
  `experience` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

-- ----------------------------
-- Records of guild
-- ----------------------------

-- ----------------------------
-- Table structure for guild_achievement
-- ----------------------------
DROP TABLE IF EXISTS `guild_achievement`;
CREATE TABLE `guild_achievement` (
  `guildId` int(10) unsigned NOT NULL,
  `achievement` smallint(5) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  `guids` text NOT NULL,
  PRIMARY KEY (`guildId`,`achievement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_achievement
-- ----------------------------

-- ----------------------------
-- Table structure for guild_achievement_progress
-- ----------------------------
DROP TABLE IF EXISTS `guild_achievement_progress`;
CREATE TABLE `guild_achievement_progress` (
  `guildId` int(10) unsigned NOT NULL,
  `criteria` smallint(5) unsigned NOT NULL,
  `counter` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  `completedGuid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildId`,`criteria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_achievement_progress
-- ----------------------------

-- ----------------------------
-- Table structure for guild_bank_eventlog
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_eventlog`;
CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Event type',
  `PlayerGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemOrMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemStackCount` smallint(5) unsigned NOT NULL DEFAULT '0',
  `DestTabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Destination Tab Id',
  `TimeStamp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`,`TabId`),
  KEY `guildid_key` (`guildid`) USING BTREE,
  KEY `Idx_PlayerGuid` (`PlayerGuid`) USING BTREE,
  KEY `Idx_LogGuid` (`LogGuid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for guild_bank_item
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_item`;
CREATE TABLE `guild_bank_item` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`SlotId`),
  KEY `guildid_key` (`guildid`) USING BTREE,
  KEY `Idx_item_guid` (`item_guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_item
-- ----------------------------

-- ----------------------------
-- Table structure for guild_bank_right
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_right`;
CREATE TABLE `guild_bank_right` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gbright` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`rid`),
  KEY `guildid_key` (`guildid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_right
-- ----------------------------

-- ----------------------------
-- Table structure for guild_bank_tab
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_tab`;
CREATE TABLE `guild_bank_tab` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `TabName` varchar(16) NOT NULL DEFAULT '',
  `TabIcon` varchar(100) NOT NULL DEFAULT '',
  `TabText` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`guildid`,`TabId`),
  KEY `guildid_key` (`guildid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_tab
-- ----------------------------

-- ----------------------------
-- Table structure for guild_eventlog
-- ----------------------------
DROP TABLE IF EXISTS `guild_eventlog`;
CREATE TABLE `guild_eventlog` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(3) unsigned NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(10) unsigned NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(10) unsigned NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(3) unsigned NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` int(10) unsigned NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`) USING BTREE,
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`) USING BTREE,
  KEY `Idx_LogGuid` (`LogGuid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';

-- ----------------------------
-- Records of guild_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for guild_finder_applicant
-- ----------------------------
DROP TABLE IF EXISTS `guild_finder_applicant`;
CREATE TABLE `guild_finder_applicant` (
  `guildId` int(10) unsigned DEFAULT NULL,
  `playerGuid` int(10) unsigned DEFAULT NULL,
  `availability` tinyint(3) unsigned DEFAULT '0',
  `classRole` tinyint(3) unsigned DEFAULT '0',
  `interests` tinyint(3) unsigned DEFAULT '0',
  `comment` varchar(255) DEFAULT NULL,
  `submitTime` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `guildId` (`guildId`,`playerGuid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of guild_finder_applicant
-- ----------------------------

-- ----------------------------
-- Table structure for guild_finder_guild_settings
-- ----------------------------
DROP TABLE IF EXISTS `guild_finder_guild_settings`;
CREATE TABLE `guild_finder_guild_settings` (
  `guildId` int(10) unsigned NOT NULL,
  `availability` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `classRoles` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `interests` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `listed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`guildId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of guild_finder_guild_settings
-- ----------------------------

-- ----------------------------
-- Table structure for guild_member
-- ----------------------------
DROP TABLE IF EXISTS `guild_member`;
CREATE TABLE `guild_member` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `guid` int(10) unsigned NOT NULL,
  `rank` tinyint(3) unsigned NOT NULL,
  `pnote` varchar(31) NOT NULL DEFAULT '',
  `offnote` varchar(31) NOT NULL DEFAULT '',
  `activity` bigint(20) NOT NULL,
  `profession1_skillID` int(10) NOT NULL DEFAULT '0',
  `weekReputation` int(10) NOT NULL DEFAULT '0',
  `profession2_rank` int(10) NOT NULL DEFAULT '0',
  `profession2_skillID` int(10) NOT NULL DEFAULT '0',
  `profession1_rank` int(10) NOT NULL DEFAULT '0',
  `weekActivity` int(10) NOT NULL DEFAULT '0',
  `profession1_level` int(10) NOT NULL DEFAULT '0',
  `profession2_level` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `guid_key` (`guid`) USING BTREE,
  KEY `guildid_key` (`guildid`) USING BTREE,
  KEY `guildid_rank_key` (`guildid`,`rank`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

-- ----------------------------
-- Records of guild_member
-- ----------------------------

-- ----------------------------
-- Table structure for guild_member_withdraw
-- ----------------------------
DROP TABLE IF EXISTS `guild_member_withdraw`;
CREATE TABLE `guild_member_withdraw` (
  `guid` int(10) unsigned NOT NULL,
  `tab0` int(10) unsigned NOT NULL DEFAULT '0',
  `tab1` int(10) unsigned NOT NULL DEFAULT '0',
  `tab2` int(10) unsigned NOT NULL DEFAULT '0',
  `tab3` int(10) unsigned NOT NULL DEFAULT '0',
  `tab4` int(10) unsigned NOT NULL DEFAULT '0',
  `tab5` int(10) unsigned NOT NULL DEFAULT '0',
  `tab6` int(10) unsigned NOT NULL DEFAULT '0',
  `tab7` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Member Dayly Withdraws';

-- ----------------------------
-- Records of guild_member_withdraw
-- ----------------------------

-- ----------------------------
-- Table structure for guild_newslog
-- ----------------------------
DROP TABLE IF EXISTS `guild_newslog`;
CREATE TABLE `guild_newslog` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TimeStamp` int(10) unsigned NOT NULL DEFAULT '0',
  `PlayerGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `LogGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `Flags` int(10) unsigned NOT NULL DEFAULT '0',
  `EventType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Value` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `Idx_PlayerGuid` (`PlayerGuid`) USING BTREE,
  KEY `Idx_LogGuid` (`LogGuid`) USING BTREE,
  KEY `guildid_key` (`guildid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Newslog';

-- ----------------------------
-- Records of guild_newslog
-- ----------------------------

-- ----------------------------
-- Table structure for guild_old_member
-- ----------------------------
DROP TABLE IF EXISTS `guild_old_member`;
CREATE TABLE `guild_old_member` (
  `guid` int(10) NOT NULL,
  `guildId` int(10) NOT NULL,
  `weekReputation` int(10) NOT NULL,
  `leaveDate` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_old_member
-- ----------------------------

-- ----------------------------
-- Table structure for guild_rank
-- ----------------------------
DROP TABLE IF EXISTS `guild_rank`;
CREATE TABLE `guild_rank` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL,
  `rname` varchar(20) NOT NULL DEFAULT '',
  `rights` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `BankMoneyPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

-- ----------------------------
-- Records of guild_rank
-- ----------------------------

-- ----------------------------
-- Table structure for instance
-- ----------------------------
DROP TABLE IF EXISTS `instance`;
CREATE TABLE `instance` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0',
  `resettime` int(10) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `completedEncounters` int(10) unsigned NOT NULL DEFAULT '0',
  `data` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `map` (`map`) USING BTREE,
  KEY `resettime` (`resettime`) USING BTREE,
  KEY `difficulty` (`difficulty`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance
-- ----------------------------

-- ----------------------------
-- Table structure for instance_reset
-- ----------------------------
DROP TABLE IF EXISTS `instance_reset`;
CREATE TABLE `instance_reset` (
  `mapid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `resettime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mapid`,`difficulty`),
  KEY `difficulty` (`difficulty`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance_reset
-- ----------------------------
INSERT INTO `instance_reset` VALUES ('33', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('36', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('249', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('249', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('269', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('409', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('469', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('509', '0', '1387339200');
INSERT INTO `instance_reset` VALUES ('531', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('532', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('533', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('533', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('534', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('540', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('542', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('543', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('544', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('545', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('546', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('547', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('548', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('550', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('552', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('553', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('554', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('555', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('556', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('557', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('558', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('560', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('564', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('565', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('568', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('574', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('575', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('576', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('578', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('580', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('585', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('595', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('598', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('599', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('600', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('601', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('602', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('603', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('603', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('604', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('608', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('615', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('615', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('616', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('616', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('619', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('624', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('624', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('631', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('631', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('631', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('631', '3', '1387425600');
INSERT INTO `instance_reset` VALUES ('632', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('643', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('644', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('645', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('649', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('649', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('649', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('649', '3', '1387425600');
INSERT INTO `instance_reset` VALUES ('650', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('657', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('658', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('668', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('669', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('669', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('669', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('669', '3', '1387425600');
INSERT INTO `instance_reset` VALUES ('670', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('671', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('671', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('671', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('671', '3', '1387425600');
INSERT INTO `instance_reset` VALUES ('720', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('720', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('720', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('720', '3', '1387425600');
INSERT INTO `instance_reset` VALUES ('724', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('724', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('724', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('724', '3', '1387425600');
INSERT INTO `instance_reset` VALUES ('725', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('754', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('754', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('754', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('754', '3', '1387425600');
INSERT INTO `instance_reset` VALUES ('755', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('757', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('757', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('859', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('938', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('939', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('940', '1', '1387166400');
INSERT INTO `instance_reset` VALUES ('967', '0', '1387425600');
INSERT INTO `instance_reset` VALUES ('967', '1', '1387425600');
INSERT INTO `instance_reset` VALUES ('967', '2', '1387425600');
INSERT INTO `instance_reset` VALUES ('967', '3', '1387425600');

-- ----------------------------
-- Table structure for item_instance
-- ----------------------------
DROP TABLE IF EXISTS `item_instance`;
CREATE TABLE `item_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemEntry` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `owner_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `creatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `giftCreatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `duration` int(10) NOT NULL DEFAULT '0',
  `charges` tinytext,
  `flags` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `enchantments` text NOT NULL,
  `randomPropertyId` smallint(5) NOT NULL DEFAULT '0',
  `durability` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `text` text,
  PRIMARY KEY (`guid`),
  KEY `idx_owner_guid` (`owner_guid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item System';

-- ----------------------------
-- Records of item_instance
-- ----------------------------

-- ----------------------------
-- Table structure for item_loot_items
-- ----------------------------
DROP TABLE IF EXISTS `item_loot_items`;
CREATE TABLE `item_loot_items` (
  `container_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'loot item entry (item_instance.itemEntry)',
  `item_count` int(10) NOT NULL DEFAULT '0' COMMENT 'stack size',
  `follow_rules` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'follow loot rules',
  `ffa` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'free-for-all',
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `counted` tinyint(1) NOT NULL DEFAULT '0',
  `under_threshold` tinyint(1) NOT NULL DEFAULT '0',
  `needs_quest` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'quest drop',
  `rnd_prop` int(10) NOT NULL DEFAULT '0' COMMENT 'random enchantment added when originally rolled',
  `rnd_suffix` int(10) NOT NULL DEFAULT '0' COMMENT 'random suffix added when originally rolled'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of item_loot_items
-- ----------------------------

-- ----------------------------
-- Table structure for item_loot_money
-- ----------------------------
DROP TABLE IF EXISTS `item_loot_money`;
CREATE TABLE `item_loot_money` (
  `container_id` int(10) NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `money` int(10) NOT NULL DEFAULT '0' COMMENT 'money loot (in copper)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of item_loot_money
-- ----------------------------

-- ----------------------------
-- Table structure for item_refund_instance
-- ----------------------------
DROP TABLE IF EXISTS `item_refund_instance`;
CREATE TABLE `item_refund_instance` (
  `item_guid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `player_guid` int(10) unsigned NOT NULL COMMENT 'Player GUID',
  `paidMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `paidExtendedCost` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`,`player_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';

-- ----------------------------
-- Records of item_refund_instance
-- ----------------------------

-- ----------------------------
-- Table structure for item_soulbound_trade_data
-- ----------------------------
DROP TABLE IF EXISTS `item_soulbound_trade_data`;
CREATE TABLE `item_soulbound_trade_data` (
  `itemGuid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `allowedPlayers` text NOT NULL COMMENT 'Space separated GUID list of players who can receive this item in trade',
  PRIMARY KEY (`itemGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';

-- ----------------------------
-- Records of item_soulbound_trade_data
-- ----------------------------

-- ----------------------------
-- Table structure for lag_reports
-- ----------------------------
DROP TABLE IF EXISTS `lag_reports`;
CREATE TABLE `lag_reports` (
  `reportId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `lagType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `latency` int(10) unsigned NOT NULL DEFAULT '0',
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`reportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';

-- ----------------------------
-- Records of lag_reports
-- ----------------------------

-- ----------------------------
-- Table structure for lfg_data
-- ----------------------------
DROP TABLE IF EXISTS `lfg_data`;
CREATE TABLE `lfg_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `dungeon` int(10) unsigned NOT NULL DEFAULT '0',
  `state` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='LFG Data';

-- ----------------------------
-- Records of lfg_data
-- ----------------------------

-- ----------------------------
-- Table structure for mail
-- ----------------------------
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stationery` tinyint(3) NOT NULL DEFAULT '41',
  `mailTemplateId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `body` longtext,
  `has_items` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `deliver_time` int(10) unsigned NOT NULL DEFAULT '0',
  `money` bigint(20) unsigned NOT NULL DEFAULT '0',
  `cod` bigint(20) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Mail System';

-- ----------------------------
-- Records of mail
-- ----------------------------

-- ----------------------------
-- Table structure for mail_items
-- ----------------------------
DROP TABLE IF EXISTS `mail_items`;
CREATE TABLE `mail_items` (
  `mail_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY (`item_guid`),
  KEY `idx_receiver` (`receiver`) USING BTREE,
  KEY `idx_mail_id` (`mail_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mail_items
-- ----------------------------

-- ----------------------------
-- Table structure for petition
-- ----------------------------
DROP TABLE IF EXISTS `petition`;
CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

-- ----------------------------
-- Records of petition
-- ----------------------------

-- ----------------------------
-- Table structure for petition_sign
-- ----------------------------
DROP TABLE IF EXISTS `petition_sign`;
CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned NOT NULL DEFAULT '0',
  `playerguid` int(10) unsigned NOT NULL DEFAULT '0',
  `player_account` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`) USING BTREE,
  KEY `Idx_ownerguid` (`ownerguid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';

-- ----------------------------
-- Records of petition_sign
-- ----------------------------

-- ----------------------------
-- Table structure for pet_aura
-- ----------------------------
DROP TABLE IF EXISTS `pet_aura`;
CREATE TABLE `pet_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effect_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculate_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackcount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` mediumint(8) NOT NULL,
  `amount1` mediumint(8) NOT NULL,
  `amount2` mediumint(8) NOT NULL,
  `base_amount0` mediumint(8) NOT NULL,
  `base_amount1` mediumint(8) NOT NULL,
  `base_amount2` mediumint(8) NOT NULL,
  `maxduration` int(11) NOT NULL DEFAULT '0',
  `remaintime` int(11) NOT NULL DEFAULT '0',
  `remaincharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`,`effect_mask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';

-- ----------------------------
-- Records of pet_aura
-- ----------------------------

-- ----------------------------
-- Table structure for pet_spell
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell`;
CREATE TABLE `pet_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';

-- ----------------------------
-- Records of pet_spell
-- ----------------------------

-- ----------------------------
-- Table structure for pet_spell_cooldown
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell_cooldown`;
CREATE TABLE `pet_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pet_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for pool_quest_save
-- ----------------------------
DROP TABLE IF EXISTS `pool_quest_save`;
CREATE TABLE `pool_quest_save` (
  `pool_id` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pool_id`,`quest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pool_quest_save
-- ----------------------------
INSERT INTO `pool_quest_save` VALUES ('348', '24636');
INSERT INTO `pool_quest_save` VALUES ('349', '14105');
INSERT INTO `pool_quest_save` VALUES ('350', '13905');
INSERT INTO `pool_quest_save` VALUES ('351', '13917');
INSERT INTO `pool_quest_save` VALUES ('352', '11377');
INSERT INTO `pool_quest_save` VALUES ('353', '11667');
INSERT INTO `pool_quest_save` VALUES ('354', '13424');
INSERT INTO `pool_quest_save` VALUES ('356', '11374');
INSERT INTO `pool_quest_save` VALUES ('357', '11376');
INSERT INTO `pool_quest_save` VALUES ('372', '28063');
INSERT INTO `pool_quest_save` VALUES ('372', '28065');
INSERT INTO `pool_quest_save` VALUES ('373', '27966');
INSERT INTO `pool_quest_save` VALUES ('373', '27992');
INSERT INTO `pool_quest_save` VALUES ('374', '27978');
INSERT INTO `pool_quest_save` VALUES ('374', '27991');
INSERT INTO `pool_quest_save` VALUES ('375', '27944');
INSERT INTO `pool_quest_save` VALUES ('375', '27971');
INSERT INTO `pool_quest_save` VALUES ('376', '28686');
INSERT INTO `pool_quest_save` VALUES ('376', '28687');
INSERT INTO `pool_quest_save` VALUES ('377', '28678');
INSERT INTO `pool_quest_save` VALUES ('377', '28683');
INSERT INTO `pool_quest_save` VALUES ('378', '28694');
INSERT INTO `pool_quest_save` VALUES ('378', '28698');
INSERT INTO `pool_quest_save` VALUES ('379', '28692');
INSERT INTO `pool_quest_save` VALUES ('379', '28693');
INSERT INTO `pool_quest_save` VALUES ('5662', '13674');
INSERT INTO `pool_quest_save` VALUES ('5663', '13763');
INSERT INTO `pool_quest_save` VALUES ('5664', '13769');
INSERT INTO `pool_quest_save` VALUES ('5665', '13773');
INSERT INTO `pool_quest_save` VALUES ('5666', '13778');
INSERT INTO `pool_quest_save` VALUES ('5667', '13784');
INSERT INTO `pool_quest_save` VALUES ('5668', '13670');
INSERT INTO `pool_quest_save` VALUES ('5669', '13616');
INSERT INTO `pool_quest_save` VALUES ('5670', '13743');
INSERT INTO `pool_quest_save` VALUES ('5671', '13746');
INSERT INTO `pool_quest_save` VALUES ('5672', '13757');
INSERT INTO `pool_quest_save` VALUES ('5673', '13754');
INSERT INTO `pool_quest_save` VALUES ('5674', '13107');
INSERT INTO `pool_quest_save` VALUES ('5675', '13114');
INSERT INTO `pool_quest_save` VALUES ('5676', '13836');
INSERT INTO `pool_quest_save` VALUES ('5677', '12958');
INSERT INTO `pool_quest_save` VALUES ('5678', '24579');
INSERT INTO `pool_quest_save` VALUES ('50003', '26227');
INSERT INTO `pool_quest_save` VALUES ('50004', '26192');
INSERT INTO `pool_quest_save` VALUES ('50005', '25160');
INSERT INTO `pool_quest_save` VALUES ('50006', '25156');
INSERT INTO `pool_quest_save` VALUES ('50007', '26557');
INSERT INTO `pool_quest_save` VALUES ('50008', '26488');

-- ----------------------------
-- Table structure for reserved_name
-- ----------------------------
DROP TABLE IF EXISTS `reserved_name`;
CREATE TABLE `reserved_name` (
  `name` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player Reserved Names';

-- ----------------------------
-- Records of reserved_name
-- ----------------------------

-- ----------------------------
-- Table structure for warden_action
-- ----------------------------
DROP TABLE IF EXISTS `warden_action`;
CREATE TABLE `warden_action` (
  `wardenId` smallint(5) unsigned NOT NULL,
  `action` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`wardenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of warden_action
-- ----------------------------

-- ----------------------------
-- Table structure for worldstates
-- ----------------------------
DROP TABLE IF EXISTS `worldstates`;
CREATE TABLE `worldstates` (
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `value` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` tinytext,
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Variable Saves';

-- ----------------------------
-- Records of worldstates
-- ----------------------------
INSERT INTO `worldstates` VALUES ('3781', '9000000', null);
INSERT INTO `worldstates` VALUES ('3801', '0', null);
INSERT INTO `worldstates` VALUES ('3802', '1', null);
INSERT INTO `worldstates` VALUES ('20001', '1387558126', null);
INSERT INTO `worldstates` VALUES ('20002', '1387558126', null);
INSERT INTO `worldstates` VALUES ('20003', '1387166400', null);
INSERT INTO `worldstates` VALUES ('20006', '1387166400', null);
INSERT INTO `worldstates` VALUES ('20007', '1388527200', null);
INSERT INTO `worldstates` VALUES ('20050', '1387511999', null);
